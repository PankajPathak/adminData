﻿
var myApp = angular.module("myApp", []);

myApp.controller("demoController", ["$scope", function ($scope) {

    $scope.SearchBy = 0;

    $scope.employees = [
        {
            Id: 1,
            Name: 'Pankaj',
            Salary: 10000,
            City: 'London'
        },
        {
            Id: 2,
            Name: 'Shashi',
            Salary: 15000,
            City: 'Delhi'
        },
        {
            Id: 3,
            Name: 'Avinash',
            Salary: 50000,
            City: 'Mumbai'
        },
        {
            Id: 4,
            Name: 'Bhajewala',
            Salary: 70000,
            City: 'Pune'
        },
        {
            Id:5,
            Name:'Vedant',
            Salary:100000,
            City:'Siwan'
        }
    ];
    $scope.Types = [
        {
            Id: 1,
            Name: 'Id'
        },
        {
            Id: 2,
            Name: 'Name'
        },
        {
            Id: 3,
            Name: 'Salary'
        },
        {
            Id: 4,
            Name: 'City'
        }
    ];

    $scope.changeEvent = function (item) {
        $scope.SearchBy = item;
    };
}]);