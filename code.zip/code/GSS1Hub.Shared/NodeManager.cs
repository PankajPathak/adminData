﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GSS1Hub.Shared.Model;
using GSS1Hub.Shared.Model.ViewModel;
using System.Data;


namespace GSS1Hub.Shared
{
    public class NodeManager
    {
        List<NodeItem> nodeList = new List<NodeItem>();
        List<TreeNode> nodeTreeList = new List<TreeNode>();
        List<UserRightNodeItem> UsernodeList = new List<UserRightNodeItem>();
        List<ModuleSubmoduleNodeModel> ModuleSubmoduleNodeList = new List<ModuleSubmoduleNodeModel>();

        DataTable dtNode;


        public List<NodeItem> ConvertToNode(DataTable dtStructuredNode)
        {
            // DataTable dtOuStructure = new DataTable();
            // dtOuStructure = createDT();

            for (int i = 0; i < dtStructuredNode.Rows.Count; i++)
            {
                if (string.IsNullOrEmpty(Convert.ToString(dtStructuredNode.Rows[i]["Pid"])) || Convert.ToString(dtStructuredNode.Rows[i]["Pid"]) == "0")
                {
                    NodeItem obj = new NodeItem();
                    obj.id = Convert.ToInt32(dtStructuredNode.Rows[i]["Id"]);
                    obj.title = Convert.ToString(dtStructuredNode.Rows[i]["Name"]);
                   // obj.IsSelected = Convert.ToBoolean(dtStructuredNode.Rows[i]["IsSelected"]);
                    // Set IsSelected
                    nodeList.Add(obj);
                    DataRow row = dtStructuredNode.Rows[i];
                    dtStructuredNode.Rows.Remove(row);

                    AppendChildNodes(obj, dtStructuredNode);
                    i--;
                }
            }
            return nodeList;
        }

        public List<NodeItem> ConvertToNode(List<DbNode> structuredNodes)
        {
            // DataTable dtOuStructure = new DataTable();
            // dtOuStructure = createDT();

            for (int i = 0; i < structuredNodes.Count; i++)
            {
                DbNode currentNode = structuredNodes[i];
                if (string.IsNullOrEmpty(Convert.ToString(currentNode.Pid)) || Convert.ToString(currentNode.Pid) == "0")
                {
                    NodeItem obj = new NodeItem();
                    obj.ModuleUrl = currentNode.ModuleUrl;
                    obj.TemplateUrl = currentNode.TemplateUrl;
                    obj.id = currentNode.Id;
                    obj.title = currentNode.Name;
                    obj.IsSelected= currentNode.IsSelected;
                    nodeList.Add(obj);
                    structuredNodes.Remove(currentNode);

                    AppendChildNodes(obj, structuredNodes);
                    i--;
                }
            }
            return nodeList;
        }

        public List<NodeItem> ConvertToNodes(DataTable dtStructuredNode)
        {
            // DataTable dtOuStructure = new DataTable();
            // dtOuStructure = createDT();

            for (int i = 0; i < dtStructuredNode.Rows.Count; i++)
            {
                if (string.IsNullOrEmpty(Convert.ToString(dtStructuredNode.Rows[i]["Pid"])) || Convert.ToString(dtStructuredNode.Rows[i]["Pid"]) == "0")
                {
                    NodeItem obj = new NodeItem();
                    obj.id = Convert.ToInt32(dtStructuredNode.Rows[i]["Id"]);
                    obj.title = Convert.ToString(dtStructuredNode.Rows[i]["Name"]);
                    obj.OuTabId = Convert.ToInt32(dtStructuredNode.Rows[i]["OuTabId"]);
                    obj.IsLI = Convert.ToInt16(dtStructuredNode.Rows[i]["IsLI"]);
                    obj.BudgetType = Convert.ToString(dtStructuredNode.Rows[i]["BudgetType"]);
                    // obj.IsSelected = Convert.ToBoolean(dtStructuredNode.Rows[i]["IsSelected"]);
                    // Set IsSelected
                    nodeList.Add(obj);
                    DataRow row = dtStructuredNode.Rows[i];
                    dtStructuredNode.Rows.Remove(row);

                    AppendChildNodesMap(obj, dtStructuredNode);
                    i--;
                }
            }
            return nodeList;
        }

        public List<TreeNode> ConvertToTreeNodes(DataTable dtStructuredNode)
        {

            for (int i = 0; i < dtStructuredNode.Rows.Count; i++)
            {
                if (string.IsNullOrEmpty(Convert.ToString(dtStructuredNode.Rows[i]["Pid"])) || Convert.ToString(dtStructuredNode.Rows[i]["Pid"]) == "0")
                {
                    TreeNode obj = new TreeNode();
                    obj.id = Convert.ToInt32(dtStructuredNode.Rows[i]["Id"]);
                    obj.ProgramName = Convert.ToString(dtStructuredNode.Rows[i]["Name"]);

                    nodeTreeList.Add(obj);
                    DataRow row = dtStructuredNode.Rows[i];
                    dtStructuredNode.Rows.Remove(row);

                    AppendChildNodesToTree(obj, dtStructuredNode);
                    i--;
                }
            }
            return nodeTreeList;
        }

        private void AppendChildNodesToTree(TreeNode parent, DataTable TreeStructure)
        {
            for (int i = 0; i < TreeStructure.Rows.Count; i++)
            {
                DataRow currentRow = TreeStructure.Rows[i];
                if (parent.id == Convert.ToInt32(Convert.ToString(currentRow["Pid"])))
                {
                    TreeNode child = new TreeNode();

                    child.id = Convert.ToInt32(currentRow["Id"]);
                    child.ProgramName = Convert.ToString(currentRow["Name"]);

                    TreeStructure.Rows.Remove(currentRow);
                    i--;
                    parent.nodes.Add(child);
                    AppendChildNodesToTree(child, TreeStructure);
                }
            }
        }

        private void AppendChildNodes(NodeItem parent, DataTable dtOuStructure)
        {
            for (int i = 0; i < dtOuStructure.Rows.Count; i++)
            {
                DataRow currentRow = dtOuStructure.Rows[i];
                if (parent.id == Convert.ToInt32(Convert.ToString(currentRow["Pid"])))
                {
                    NodeItem child = new NodeItem();
                    
                    child.id = Convert.ToInt32(currentRow["Id"]);
                    child.title = Convert.ToString(currentRow["Name"]);

                    dtOuStructure.Rows.Remove(currentRow);
                    i--;
                    parent.nodes.Add(child);
                    AppendChildNodes(child, dtOuStructure);
                }
            }
        }
        private void AppendChildNodes(NodeItem parent, List<DbNode> nodes)
        {
            for (int i = 0; i < nodes.Count; i++)
            {
                DbNode currentNode = nodes[i];
                if (parent.id == Convert.ToInt32(Convert.ToString(currentNode.Pid)))
                {
                    NodeItem child = new NodeItem();
                    child.ModuleUrl = currentNode.ModuleUrl;
                    child.TemplateUrl = currentNode.TemplateUrl;
                    child.id = currentNode.Id;
                    child.title = currentNode.Name;
                    child.IsSelected = currentNode.IsSelected;
                    nodes.Remove(currentNode);
                    i--;
                    parent.nodes.Add(child);
                    AppendChildNodes(child, nodes);
                }
            }
        }

        private void AppendChildNodesMap(NodeItem parent, DataTable dtOuStructure)
        {
            for (int i = 0; i < dtOuStructure.Rows.Count; i++)
            {
                DataRow currentRow = dtOuStructure.Rows[i];
                if (parent.id == Convert.ToInt32(Convert.ToString(currentRow["Pid"])) && parent.IsLI == 0)
                {
                    NodeItem child = new NodeItem();

                    child.id = Convert.ToInt32(currentRow["Id"]);
                    child.title = Convert.ToString(currentRow["Name"]);
                    child.OuTabId = Convert.ToInt32(currentRow["OuTabId"]);
                    child.IsLI = Convert.ToInt16(currentRow["IsLI"]);
                    child.BudgetType = Convert.ToString(currentRow["BudgetType"]);

                    dtOuStructure.Rows.Remove(currentRow);
                    i--;
                    parent.nodes.Add(child);
                    AppendChildNodesMap(child, dtOuStructure);
                }
            }
        }

        #region New common code for Convert to DataTable
        public DataTable ConvertToDatatable(List<OuNode> nodeJson, long entityId, string dbType)
        {
            dtNode = this.CreateDT(dbType);
            for (int i = 0; i < nodeJson.Count; i++)
            {
                dtNode.Rows.Add(nodeJson[i].id, nodeJson[i].title, "", entityId);
                GetChildNodes(nodeJson[i], dtNode, entityId);
            }
            return dtNode;
        }
        private void GetChildNodes(OuNode rootNode, DataTable dtNode, long entityId)
        {
            foreach (OuNode childNode in rootNode.nodes)
            {
                //Add child node id and title
                dtNode.Rows.Add(childNode.id, childNode.title, rootNode.id, entityId);
                GetChildNodes(childNode, dtNode, entityId);
            }
        }

        public DataTable CreateDT(string dbType)
        {
            DataTable dtJson = new DataTable(dbType);

            dtJson.Columns.Add("Id");
            dtJson.Columns.Add("Title");
            dtJson.Columns.Add("ParentId");
            dtJson.Columns.Add("EntityId");

            return dtJson;


        }
        #endregion

        #region previous Convert to Datatable Code
        //public DataTable ConvertToDatatable(List<NodeItem> nodeJson)
        //{
        //    dtNode = this.CreateDT();
        //    for (int i = 0; i < nodeJson.Count; i++)
        //    {
        //        dtNode.Rows.Add(nodeJson[i].Id, nodeJson[i].Title, "");
        //        GetChildNodes(nodeJson[i], dtNode);
        //    }
        //    return dtNode;
        //}

        //private void GetChildNodes(NodeItem rootNode, DataTable dtNode)
        //{
        //    foreach (NodeItem childNode in rootNode.NodeList)
        //    {
        //        //Add child node id and title
        //        dtNode.Rows.Add(childNode.Id, childNode.Title, rootNode.Id);
        //        GetChildNodes(childNode, dtNode);
        //    }
        //}

        //public DataTable CreateDT()
        //{
        //    DataTable dtJson = new DataTable();
        //    dtJson.Columns.Add("Id");
        //    dtJson.Columns.Add("Name");
        //    dtJson.Columns.Add("Pid");
        //    dtJson.Columns.Add("EntityId");
        //    return dtJson;


        //}

        #endregion


        public List<UserRightNodeItem> ConvertToUserRightNode(DataTable dtuserNode)
        {
            // DataTable dtOuStructure = new DataTable();
            // dtOuStructure = createDT();

            for (int i = 0; i < dtuserNode.Rows.Count; i++)
            {
                if (string.IsNullOrEmpty(Convert.ToString(dtuserNode.Rows[i]["PId"])) || Convert.ToString(dtuserNode.Rows[i]["PId"]) == "0")
                {
                    UserRightNodeItem obj = new UserRightNodeItem();
                    obj.Id = Convert.ToInt32(dtuserNode.Rows[i]["Id"]);
                    obj.Title = Convert.ToString(dtuserNode.Rows[i]["Title"]);
                    obj.Create = dtuserNode.Rows[i]["Create"] == DBNull.Value ? false: Convert.ToBoolean(dtuserNode.Rows[i]["Create"]);
                    obj.Delete = dtuserNode.Rows[i]["Delete"] == DBNull.Value ? false : Convert.ToBoolean(dtuserNode.Rows[i]["Delete"]);
                    obj.Edit = dtuserNode.Rows[i]["Edit"] == DBNull.Value ? false : Convert.ToBoolean(dtuserNode.Rows[i]["Edit"]);
                    obj.Read = dtuserNode.Rows[i]["Read"] == DBNull.Value ? false : Convert.ToBoolean(dtuserNode.Rows[i]["Read"]);
                    obj.IsRoot = Convert.ToBoolean(dtuserNode.Rows[i]["IsRoot"]);
                    obj.FRId = dtuserNode.Rows[i]["FRId"] != DBNull.Value ? Convert.ToInt32(dtuserNode.Rows[i]["FRId"]) : 0;

                    UsernodeList.Add(obj);
                    DataRow row = dtuserNode.Rows[i];
                    dtuserNode.Rows.Remove(row);

                    AppendUserRightChildNodes(obj, dtuserNode);
                    i--;
                }
            }
            return UsernodeList;

        }

        public void AppendUserRightChildNodes(UserRightNodeItem parent, DataTable dtuserNode)
        {
            for (int i = 0; i < dtuserNode.Rows.Count; i++)
            {
                DataRow currentRow = dtuserNode.Rows[i];
                if (parent.Id == Convert.ToInt32(Convert.ToString(currentRow["PId"])))
                {
                    UserRightNodeItem child = new UserRightNodeItem();
                    child.Id = Convert.ToInt32(dtuserNode.Rows[i]["Id"]);
                    child.Title = Convert.ToString(dtuserNode.Rows[i]["Title"]);
                    child.Create = Convert.ToBoolean(dtuserNode.Rows[i]["Create"]);
                    child.Delete = Convert.ToBoolean(dtuserNode.Rows[i]["Delete"]);
                    child.Edit = Convert.ToBoolean(dtuserNode.Rows[i]["Edit"]);
                    child.Read = Convert.ToBoolean(dtuserNode.Rows[i]["Read"]);
                    child.IsRoot = Convert.ToBoolean(dtuserNode.Rows[i]["IsRoot"]);
                    child.FRId = dtuserNode.Rows[i]["FRId"] != DBNull.Value ? Convert.ToInt32(dtuserNode.Rows[i]["FRId"]) : 0;
                    dtuserNode.Rows.Remove(currentRow);
                    i--;
                    parent.nodes.Add(child);
                    AppendUserRightChildNodes(child, dtuserNode);
                }
            }
        }

        #region Shared 
        public List<ModuleSubmoduleNodeModel> ConvertToModuleSubmoduleNode(DataTable dtModuleSubmoduleNode)
        {
            for (int i = 0; i < dtModuleSubmoduleNode.Rows.Count; i++)
            {
                if (string.IsNullOrEmpty(Convert.ToString(dtModuleSubmoduleNode.Rows[i]["PId"])) || Convert.ToString(dtModuleSubmoduleNode.Rows[i]["PId"]) == "0")
                {
                    ModuleSubmoduleNodeModel obj = new ModuleSubmoduleNodeModel();
                    obj.Id = Convert.ToInt32(dtModuleSubmoduleNode.Rows[i]["Id"]);
                    obj.Title = Convert.ToString(dtModuleSubmoduleNode.Rows[i]["Title"]);
                    obj.Create = dtModuleSubmoduleNode.Rows[i]["Create"] == DBNull.Value ? false : Convert.ToBoolean(dtModuleSubmoduleNode.Rows[i]["Create"]);
                    obj.Read = dtModuleSubmoduleNode.Rows[i]["Read"] == DBNull.Value ? false : Convert.ToBoolean(dtModuleSubmoduleNode.Rows[i]["Read"]);
                    obj.Edit = dtModuleSubmoduleNode.Rows[i]["Edit"] == DBNull.Value ? false : Convert.ToBoolean(dtModuleSubmoduleNode.Rows[i]["Edit"]);
                    obj.Delete = dtModuleSubmoduleNode.Rows[i]["Delete"] == DBNull.Value ? false : Convert.ToBoolean(dtModuleSubmoduleNode.Rows[i]["Delete"]);
                    obj.IsSelected = Convert.ToBoolean(dtModuleSubmoduleNode.Rows[i]["IsSelected"]);
                    obj.IsRoot = Convert.ToBoolean(dtModuleSubmoduleNode.Rows[i]["IsRoot"]);
                    obj.FRId = dtModuleSubmoduleNode.Rows[i]["FRId"] != DBNull.Value ? Convert.ToInt32(dtModuleSubmoduleNode.Rows[i]["FRId"]) : 0;
                    obj.ModuleUrl = dtModuleSubmoduleNode.Rows[i]["ModuleUrl"] != DBNull.Value ? Convert.ToString(dtModuleSubmoduleNode.Rows[i]["ModuleUrl"]): "";

                    ModuleSubmoduleNodeList.Add(obj);
                    DataRow row = dtModuleSubmoduleNode.Rows[i];
                    dtModuleSubmoduleNode.Rows.Remove(row);

                    AppendModuleSubmoduleChildNodes(obj, dtModuleSubmoduleNode);
                    i--;
                }
            }
            return ModuleSubmoduleNodeList;

        }

        public void AppendModuleSubmoduleChildNodes(ModuleSubmoduleNodeModel parent, DataTable dtModuleSubmoduleNode)
        {
            for (int i = 0; i < dtModuleSubmoduleNode.Rows.Count; i++)
            {
                DataRow currentRow = dtModuleSubmoduleNode.Rows[i];
                if (parent.Id == Convert.ToInt32(Convert.ToString(currentRow["PId"])))
                {
                    ModuleSubmoduleNodeModel child = new ModuleSubmoduleNodeModel();
                    child.Id = Convert.ToInt32(dtModuleSubmoduleNode.Rows[i]["Id"]);
                    child.Title = Convert.ToString(dtModuleSubmoduleNode.Rows[i]["Title"]);
                    child.Create = dtModuleSubmoduleNode.Rows[i]["Create"] == DBNull.Value ? false : Convert.ToBoolean(dtModuleSubmoduleNode.Rows[i]["Create"]);
                    child.Read = dtModuleSubmoduleNode.Rows[i]["Read"] == DBNull.Value ? false : Convert.ToBoolean(dtModuleSubmoduleNode.Rows[i]["Read"]);
                    child.Edit = dtModuleSubmoduleNode.Rows[i]["Edit"] == DBNull.Value ? false : Convert.ToBoolean(dtModuleSubmoduleNode.Rows[i]["Edit"]);
                    child.Delete = dtModuleSubmoduleNode.Rows[i]["Delete"] == DBNull.Value ? false : Convert.ToBoolean(dtModuleSubmoduleNode.Rows[i]["Delete"]);
                    child.IsSelected = Convert.ToBoolean(dtModuleSubmoduleNode.Rows[i]["IsSelected"]);
                    child.IsRoot = Convert.ToBoolean(dtModuleSubmoduleNode.Rows[i]["IsRoot"]);
                    child.FRId = dtModuleSubmoduleNode.Rows[i]["FRId"] != DBNull.Value ? Convert.ToInt32(dtModuleSubmoduleNode.Rows[i]["FRId"]) : 0;
                    child.ModuleUrl = dtModuleSubmoduleNode.Rows[i]["ModuleUrl"] != DBNull.Value ? Convert.ToString(dtModuleSubmoduleNode.Rows[i]["ModuleUrl"]) : "";
                    dtModuleSubmoduleNode.Rows.Remove(currentRow);
                    i--;
                    parent.nodes.Add(child);
                    AppendModuleSubmoduleChildNodes(child, dtModuleSubmoduleNode);
                }
            }
        }

        #endregion


    }
}
