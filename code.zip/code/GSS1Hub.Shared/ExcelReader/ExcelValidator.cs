﻿using GSS1Hub.Shared.ExcelReader.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Excel = Microsoft.Office.Interop.Excel;

namespace GSS1Hub.Shared.ExcelReader
{
    public class ExcelValidator : IExcelValidator
    {
        private readonly string jsonPath;
        private readonly List<string> JsonColoumNames = new List<string>();
        private readonly Dictionary<string, ColumnsConfig> DictForColoumConfig = new Dictionary<string, ColumnsConfig>();
        private readonly ExcelConfig excelConfig = new ExcelConfig();

        public string DateFormat { get; set; }

        private int noOfSheetProcess;

        public int NoOfSheetProcess
        {
            get { return noOfSheetProcess; }
            set
            {
                if (value < 1)
                    noOfSheetProcess = 1;
                else
                    noOfSheetProcess = value;
            }
        }

        public ExcelValidator(string jsonPath)
        {
            this.jsonPath = jsonPath.Trim();
            this.JsonColoumNames = GetCololumNamesFromJson();
            this.DictForColoumConfig = GetCololumObjectFromJson();
            this.excelConfig = GetexcelConfigFromJson();
            this.DateFormat = excelConfig.DateFormat.Trim();
            this.NoOfSheetProcess = excelConfig.NoOfSheetProcess;
        }

        #region private

        private ExcelConfig GetexcelConfigFromJson()
        {
            using (StreamReader r = new StreamReader(jsonPath))
            {
                string json = r.ReadToEnd();
                RootObject excelConfig = (new JSonHelper()).ConvertJSonToObject<RootObject>(json);
                return excelConfig.ExcelConfig;
            }
        }

        private Dictionary<string, ColumnsConfig> GetCololumObjectFromJson()
        {
            using (StreamReader r = new StreamReader(jsonPath))
            {
                string json = r.ReadToEnd();

                RootObject excelConfig = (new JSonHelper()).ConvertJSonToObject<RootObject>(json);
                Dictionary<string, ColumnsConfig> DictForColoumConfig = new Dictionary<string, ColumnsConfig>();
                foreach (var item in excelConfig.ExcelConfig.Coloums)
                {
                    DictForColoumConfig.Add(item.Name.Trim(), item);
                }

                return DictForColoumConfig;
            }
        }

        private List<string> GetCololumNamesFromJson()
        {
            using (StreamReader r = new StreamReader(jsonPath))
            {
                string json = r.ReadToEnd();

                RootObject excelConfig = (new JSonHelper()).ConvertJSonToObject<RootObject>(json);

                List<string> ColoumNames = new List<string>();
                foreach (var item in excelConfig.ExcelConfig.Coloums)
                {
                    ColoumNames.Add(item.Name.Trim());
                }

                return ColoumNames;
            }
        }

        private List<string> GetCololumNamesOfExcel(Excel.Range excelRange)
        {
            List<string> excelHeaders = new List<string>();
            for (int i = 1; i <= excelRange.Columns.Count; i++)
            {
                string Headervalue = string.Empty;

                if (excelRange.Cells[1, i] != null && excelRange.Cells[1, i].Value2 != null)
                    Headervalue = excelRange.Cells[1, i].Value2.ToString();

                excelHeaders.Add(Headervalue.Trim());
            }
            return excelHeaders;
        }

        private ExcelCell ValidateCellWithConfig(ExcelCell cell, ColumnsConfig coloumConfig, ref string errorMessage)
        {
            if (string.IsNullOrEmpty(cell.Value.ToString()))
            {
                #region Required

                if (coloumConfig.Required)
                {
                    cell.TooltipText = "Field is requried";
                    cell.CSSClass += " errorcell";
                    errorMessage += cell.HeaderName + "  " + cell.TooltipText.ToLower() + ",";
                }

                #endregion Required
            }
            else
            {
                #region DataType

                if (!string.IsNullOrEmpty(coloumConfig.DataType))
                {
                    #region string

                    if (coloumConfig.DataType.ToLower() == "string")
                    {
                        cell.Value = cell.Value.ToString();
                        if (coloumConfig.Maxlength > 0)
                        {
                            if (cell.Value.ToString().Length > coloumConfig.Maxlength)
                            {
                                cell.TooltipText = "Field exceeds the maximum length ";
                                cell.CSSClass += " errorcell";
                                errorMessage += cell.HeaderName + "  " + cell.TooltipText.ToLower() + ",";
                            }
                        }
                        if (coloumConfig.Minlength > 0)
                        {
                            if (cell.Value.ToString().Length < coloumConfig.Minlength)
                            {
                                cell.TooltipText = "Field lenght is less then " + coloumConfig.Minlength;
                                cell.CSSClass += " errorcell";
                                errorMessage += cell.HeaderName + "  " + cell.TooltipText.ToLower() + ",";
                            }
                        }
                    }

                    #endregion string

                    #region integer

                    else if (coloumConfig.DataType.ToLower() == "integer")
                    {
                        cell.Value = cell.Value.ToString();
                        int i;
                        if (int.TryParse(cell.Value.ToString(), out i))
                        {
                            //public string maxValue { get; set; }
                            if (coloumConfig.MinValue > 0 && i < coloumConfig.MinValue)
                            {
                                cell.TooltipText = "Field can not be less then " + coloumConfig.MinValue;
                                cell.CSSClass += " errorcell";
                                errorMessage += cell.HeaderName + "  " + cell.TooltipText.ToLower() + ",";
                            }
                            ////public string minValue { get; set; }
                            if (coloumConfig.MaxValue > 0 && i > coloumConfig.MaxValue)
                            {
                                cell.TooltipText = "Field can not be greater then " + coloumConfig.MaxValue;
                                cell.CSSClass += " errorcell";
                                errorMessage += cell.HeaderName + "  " + cell.TooltipText.ToLower() + ",";
                            }
                        }
                        else
                        {
                            cell.TooltipText = "Field is not integer ";
                            cell.CSSClass += " errorcell";
                            errorMessage += cell.HeaderName + "  " + cell.TooltipText.ToLower() + ",";
                        }
                    }

                    #endregion integer

                    #region decimal

                    else if (coloumConfig.DataType.ToLower() == "decimal")
                    {
                        cell.Value = cell.Value.ToString();
                        decimal i;
                        if (decimal.TryParse(cell.Value.ToString(), out i))
                        {
                            //public string minValue { get; set; }
                            if (coloumConfig.DeciMinValue > 0 && i < coloumConfig.DeciMinValue)
                            {
                                cell.TooltipText = "Field can not be less then " + coloumConfig.DeciMinValue;
                                cell.CSSClass += " errorcell";
                                errorMessage += cell.HeaderName + "  " + cell.TooltipText.ToLower() + ",";
                            }
                            ////public string minValue { get; set; }
                            if (coloumConfig.DeciMaxValue > 0 && i > coloumConfig.DeciMaxValue)
                            {
                                cell.TooltipText = "Field can not be greater then " + coloumConfig.DeciMaxValue;
                                cell.CSSClass += " errorcell";
                                errorMessage += cell.HeaderName + "  " + cell.TooltipText.ToLower() + ",";
                            }
                        }
                        else
                        {
                            cell.TooltipText = "Field is not decimal ";
                            cell.CSSClass += " errorcell";
                            errorMessage += cell.HeaderName + "  " + cell.TooltipText.ToLower() + ",";
                        }
                    }

                    #endregion decimal

                    #region date

                    else if (coloumConfig.DataType.ToLower() == "date" || coloumConfig.DataType.ToLower() == "time" || coloumConfig.DataType.ToLower() == "datetime")
                    {
                        DateTime parsedDateTime;
                        string[] formats = new string[1];
                        formats[0] = coloumConfig.DataFormat;
                        bool _flag = DateTime.TryParseExact(cell.Value.ToString(), formats, new System.Globalization.CultureInfo("en-US"),
                                          System.Globalization.DateTimeStyles.None, out parsedDateTime);

                        Type t = cell.Value.GetType();

                        _flag = DateTime.TryParse(cell.Value.ToString(), out parsedDateTime);
                        if (!_flag)
                        {
                            cell.TooltipText = "Field is not DateTime format ";
                            cell.CSSClass += " errorcell";
                            errorMessage += cell.HeaderName + "  " + cell.TooltipText.ToLower() + ",";
                        }
                    }

                    #endregion date

                    #region email

                    else if (coloumConfig.DataType.ToLower() == "email")
                    {
                        if (!System.Text.RegularExpressions.Regex.IsMatch(cell.Value.ToString()
                            , "^([0-9a-zA-Z]([-\\.\\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\\w]*[0-9a-zA-Z]\\.)+[a-zA-Z]{2,9})$"))
                        {
                            cell.TooltipText = "Field is not not a valid e-mail address ";
                            cell.CSSClass += " errorcell";
                            errorMessage += cell.HeaderName + "  " + cell.TooltipText.ToLower() + ",";
                        }
                    }

                    #endregion email
                }

                #endregion DataType
            }

            if (coloumConfig.ExpectedValues.Trim().Length > 0)
            {
                if (0 == (from expvalues in coloumConfig.ExpectedValues.Split(',')
                          where expvalues.ToString().Trim().ToLower() == cell.Value.ToString().ToLower()
                          select expvalues).Count())
                {
                    cell.TooltipText = "Field do not have expected value";
                    cell.CSSClass += " errorcell";
                    errorMessage += cell.HeaderName + "  " + cell.TooltipText.ToLower() + ",";
                }
            }
            if (coloumConfig.UnexpectedValues.Trim().Length > 0)
            {
                int i = (from expvalues in coloumConfig.UnexpectedValues.Split(',')
                         where expvalues.ToString().Trim().ToLower() == cell.Value.ToString().Trim().ToLower()
                         select expvalues).Count();
                if (0 < i)
                {
                    cell.TooltipText = "Field can not contain " + cell.Value.ToString();
                    cell.CSSClass += " errorcell";
                    errorMessage += cell.HeaderName + "  " + cell.TooltipText.ToLower() + ",";
                }
            }

            return cell;
        }

        #endregion private

        public bool ValidateHeader(Excel.Range excelRange, ref string errorMsg)
        {
            bool flag = false;
            if (excelRange.Columns.Count == JsonColoumNames.Count)
            {
                List<string> excelColoumNames = GetCololumNamesOfExcel(excelRange);

                //var same = excelColoumNames.Except(JsonColoumNames).Count() == 0 &&
                //          JsonColoumNames.Except(excelColoumNames).Count() == 0;

                if (excelConfig.SequenceRequired)
                    flag = excelColoumNames.SequenceEqual(JsonColoumNames);
                else
                    flag = excelColoumNames.OrderBy(x => x).SequenceEqual(JsonColoumNames.OrderBy(y => y));

                if (!flag)
                    errorMsg = "Header Miss Match. Please check Sequence of Header.";
            }
            else
            {
                errorMsg = "Header Miss Match. Please check Header Name or no of Header.";
            }
            return flag;
        }

        public ExcelCell ValidateCell(ExcelCell cell, ref string errorMessage)
        {
            //try
            //{
            ColumnsConfig coloumConfig;
            DictForColoumConfig.TryGetValue(cell.HeaderName, out coloumConfig);
            cell.DBColoumName = coloumConfig.DBColoumName;

            #region Depandency

            if (!string.IsNullOrEmpty(coloumConfig.CopyConfigFormColumn))
            {
                ColumnsConfig copycoloumConfig = new ColumnsConfig();
                DictForColoumConfig.TryGetValue(coloumConfig.CopyConfigFormColumn, out copycoloumConfig);
                return ValidateCellWithConfig(cell, copycoloumConfig, ref errorMessage);
            }
            else
            {
                return ValidateCellWithConfig(cell, coloumConfig, ref errorMessage);
            }

            #endregion Depandency

            //}
            //catch (Exception ex)
            //{
            //    errorMessage += ex.Message;

            //}

            //return cell;
        }

        public List<ExcelCell> ValidateRow(List<ExcelCell> listExcelCell, ref string errorMessage)
        {
            if (excelConfig.ColumnDependency != null && excelConfig.ColumnDependency.Count > 0)
            {
                foreach (var ColumnDependency in excelConfig.ColumnDependency)
                {
                    var cell1 = (from n in listExcelCell
                                 where n.HeaderName == ColumnDependency.Column1
                                 select n).FirstOrDefault();

                    var cell2 = (from n in listExcelCell
                                 where n.HeaderName == ColumnDependency.Column2
                                 select n)
                                      .FirstOrDefault();

                    if (cell1 != null || cell2 != null)
                    {
                        //cell1.Value = cell1.Value.ToString();
                        //cell2.Value = cell2.Value.ToString();

                        //Same Value
                        if (ColumnDependency.DependencyType.ToLower() == "C1==C2".ToLower())
                        {
                            errorMessage += cell1.Value.ToString().Equals(cell2.Value.ToString()) ? "" : " Value should be same of column " + ColumnDependency.Column1 + " and " + ColumnDependency.Column2 + ";";
                            if (!cell1.Value.ToString().Equals(cell2.Value.ToString()))
                            {
                                cell1.CSSClass += " errorcell";
                                cell2.CSSClass += " errorcell";
                            }
                        }
                        else if (ColumnDependency.DependencyType.ToLower() == "C1:C2==TRUE".ToLower())
                        {
                            if (cell1.Value.ToString().Length > 0)
                            {
                                if (!(cell2.Value.ToString().Length > 0))
                                {
                                    cell1.CSSClass += " errorcell";
                                    cell2.CSSClass += " errorcell";
                                    errorMessage += ColumnDependency.Column1 + " and " + ColumnDependency.Column2 + " column is not follow validation;";
                                }
                            }
                            else
                            {
                                if (cell2.Value.ToString().Length > 0)
                                {
                                    cell1.CSSClass += " errorcell";
                                    cell2.CSSClass += " errorcell";
                                    errorMessage += ColumnDependency.Column1 + " and " + ColumnDependency.Column2 + " column is not follow validation;";
                                }
                            }

                            //if (!(cell1.Value.Length > 0 && cell2.Value.Length > 0))
                            //{
                            //    cell1.CSSClass += " errorcell";
                            //    cell2.CSSClass += " errorcell";
                            //    errorMessage += ColumnDependency.Column1 + " and " + ColumnDependency.Column2 + " column is not follow validation;";
                            //}
                            //if (cell1.Value.Length == 0 && cell2.Value.Length == 0)
                            //{
                            //    cell1.CSSClass += " errorcell";
                            //    cell2.CSSClass += " errorcell";
                            //    errorMessage += ColumnDependency.Column1 + " and " + ColumnDependency.Column2 + " column is not follow validation;";
                            //}
                        }
                        else if (ColumnDependency.DependencyType.ToLower() == "C1:C2==FALSE".ToLower())
                        {
                            if (cell1.Value.ToString().Length > 0) // && cell2Value.Value.Length == 0))
                            {
                                if (cell2.Value.ToString().Length != 0)
                                {
                                    errorMessage += ColumnDependency.Column1 + " and " + ColumnDependency.Column2 + " column is not follow validation;";
                                    cell1.CSSClass += " errorcell";
                                    cell2.CSSClass += " errorcell";
                                }
                            }
                            else
                            {
                                if (cell2.Value.ToString().Length == 0)
                                {
                                    cell1.CSSClass += " errorcell";
                                    cell2.CSSClass += " errorcell";
                                    errorMessage += ColumnDependency.Column1 + " and " + ColumnDependency.Column2 + " column is not follow validation;";
                                }
                            }
                        }
                        else if (ColumnDependency.DependencyType.ToUpper() == "IFC1:THENC2")
                        {
                            foreach (var item in ColumnDependency.C1ValueC2Values.Split('|'))
                            {
                                if (cell1.Value.ToString() == item.Trim().Split(':')[0].Trim())
                                {
                                    if ((from c in item.Split(':')[1].Split('/') where c.Trim() == cell2.Value.ToString() select c).Count() < 1)
                                    {
                                        cell1.CSSClass += " errorcell";
                                        cell2.CSSClass += " errorcell";
                                        errorMessage += "if " + ColumnDependency.Column1 + " have " + cell1.Value.ToString() + " Text then " + ColumnDependency.Column2 + " can have only " + item.Split(':')[1] + " Text";
                                    }
                                }
                            }
                        }
                    }
                }
            }

            return listExcelCell;
        }
    }
}