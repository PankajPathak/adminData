﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace GSS1Hub.Shared.ExcelReader.Models
{
    [DataContract]
    public class ExcelFile
    {
        /// <summary>
        ///
        /// </summary>
        public ExcelFile()
        {
            this.ExcelFileName = "";
            this.ExcelErrorMessage = "";
            this.DateFormat = "dmy";
        }

        [DataMember]
        public string ExcelFileName { get; set; }

        [DataMember]
        public string ExcelErrorMessage { get; set; }

        [DataMember]
        public string DateFormat { get; set; }

        [DataMember]
        public List<ExcelSheet> ExcelSheetCollection { get; set; }

        [DataMember]
        public string ExcelGuid { get; set; }
    }
}