﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSS1Hub.Shared.ExcelReader.Models
{
    public class ColumnsConfig
    {
        public ColumnsConfig()
        {
            this.Required = false;
            this.CopyConfigFormColumn = string.Empty;
            this.DependToColumn = string.Empty;
            this.DataType = "string";

            this.Maxlength = -1;
            this.Minlength = -1;

            this.MinValue = -1;
            this.MaxValue = -1;

            this.DeciMinValue = -1.0M;
            this.DeciMaxValue = -1.0M;

            this.DataFormat = "dd/MM/yyyy";
        }

        public string DBColoumName { get; set; }
        public string Name { get; set; }

        public bool Required { get; set; }

        public string DataType { get; set; }

        //Interger
        public int MaxValue { get; set; }

        public int MinValue { get; set; }

        //decimal
        public decimal DeciMaxValue { get; set; }

        public decimal DeciMinValue { get; set; }

        //String
        public int Maxlength { get; set; }

        //DataFormat
        public string DataFormat { get; set; }

        public int Minlength { get; set; }

        public string DependToColumn { get; set; }

        public string CopyConfigFormColumn { get; set; }
    }
}