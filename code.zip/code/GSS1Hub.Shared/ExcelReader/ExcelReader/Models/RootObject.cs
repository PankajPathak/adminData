﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSS1Hub.Shared.ExcelReader.Models
{
    public class RootObject
    {
        public ExcelConfig ExcelConfig { get; set; }
    }
}
