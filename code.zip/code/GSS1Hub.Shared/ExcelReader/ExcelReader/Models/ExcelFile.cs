﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace GSS1Hub.Shared.ExcelReader.Models
{
    [DataContract]
    public class ExcelFile
    {
        public ExcelFile()
        {
            this.ExcelFileName = "";
            this.ErrorMassage = "";
            this.DateFormat = "dmy";
        }

        [DataMember]
        public string ExcelFileName { get; set; }

        [DataMember]
        public string ErrorMassage { get; set; }

        [DataMember]
        public string DateFormat { get; set; }

        [DataMember]
        public List<ExcelSheet> ExcelSheetCollection { get; set; }
    }
}