﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSS1Hub.Shared.ExcelReader.Models
{
    public class ExcelConfig
    {
        public ExcelConfig()
        {
            this.SequenceRequired = false;
            this.DateFormat = "dmy";
        }

        public bool SequenceRequired { get; set; }
        public List<ColumnsConfig> Coloums { get; set; }
        public List<ColumnDependency> ColumnDependency { get; set; }
        public string DateFormat { get; set; }
    }
}