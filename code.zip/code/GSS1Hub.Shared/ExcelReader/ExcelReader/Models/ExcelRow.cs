﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace GSS1Hub.Shared.ExcelReader.Models
{
    [DataContract]
    public class ExcelRow
    {
        [DataMember]
        public int RowNumber { get; set; }
        [DataMember]
        public List<ExcelCell> CellCollection { get; set; }
        [DataMember]
        public string RowConclusion { get; set; }
        
        [DataMember]
        public bool isRowValidated { get; set; }
    }
}
