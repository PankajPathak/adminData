﻿using System.Runtime.Serialization;

namespace GSS1Hub.Shared.ExcelReader.Models
{
    [DataContract]
    public class ExcelCell
    {
        public ExcelCell()
        {
            this.TooltipText = string.Empty;
            this.CSSClass = string.Empty;
        }

        [DataMember]
        public string Value { get; set; }

        [DataMember]
        public string HeaderName { get; set; }

        [DataMember]
        public string TooltipText { get; set; }

        [DataMember]
        public string CSSClass { get; set; }

        [DataMember]
        public string DBColoumName { get; set; }
    }
}