﻿using GSS1Hub.Shared.ExcelReader.Models;
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;
using Excel = Microsoft.Office.Interop.Excel;

namespace GSS1Hub.Shared.ExcelReader
{
    public class ExcelReader
    {
        private IExcelValidator excelValidator = null;
        public bool CustomValidation { get; set; }

        public ExcelReader()
        {
            //excelValidator = new ExcelValidator(@"PATHOFJSON");
        }

        public ExcelReader(IExcelValidator excelValidator)
        {
            this.excelValidator = excelValidator;
        }

        public ExcelFile ExcelToSheet(string FilePath)
        {
            //Create COM Objects. Create a COM object for everything that is referenced
            Excel.Application xlApp = new Excel.Application();
            Excel.Workbook xlWorkbook = xlApp.Workbooks.Open(FilePath);
            int sheetcount = xlWorkbook.Worksheets.Count;

            ExcelFile excelFile = new ExcelFile();
            List<ExcelSheet> listExcelSheet = new List<ExcelSheet>();

            for (int sheet = 1; sheet <= sheetcount; sheet++)
            {
                ExcelSheet excelSheet = new ExcelSheet();
                Excel._Worksheet xlWorksheet = xlWorkbook.Sheets[sheet];
                excelSheet = GenrateExcelObject(xlWorksheet);
                listExcelSheet.Add(excelSheet);

                //Marshal.ReleaseComObject(xlRange);
                Marshal.ReleaseComObject(xlWorksheet);
            }
            excelFile.DateFormat = excelValidator.DateFormat;

            excelFile.ExcelSheetCollection = listExcelSheet;

            //JsonData.Append("]");

            //cleanup
            GC.Collect();
            GC.WaitForPendingFinalizers();

            //close and release
            xlWorkbook.Close();
            Marshal.ReleaseComObject(xlWorkbook);

            //quit and release
            xlApp.Quit();
            Marshal.ReleaseComObject(xlApp);
            return excelFile;
        }

        private string GenrateJSONWithStringBuilder(Excel.Range xlRange)
        {
            var JSONString = new StringBuilder();
            int rowCount = xlRange.Rows.Count;
            int colCount = xlRange.Columns.Count;

            //iterate over the rows and columns and print to the console as it appears in the file
            //excel is not zero based!!

            JSONString.Append("[");

            #region Create Json Data

            if (rowCount > 2 && colCount > 1)
            {
                for (int i = 2; i <= rowCount; i++)
                {
                    JSONString.Append("{");
                    for (int j = 1; j <= colCount; j++)
                    {
                        string Cellvalue;
                        if (xlRange.Cells[i, j] != null && xlRange.Cells[i, j].Value2 != null)
                            Cellvalue = xlRange.Cells[i, j].Value2.ToString();
                        else
                            Cellvalue = "";
                        string Headervalue;
                        if (xlRange.Cells[1, j] != null && xlRange.Cells[1, j].Value2 != null)
                            Headervalue = xlRange.Cells[1, j].Value2.ToString();
                        else
                            Headervalue = "";

                        if (j < colCount - 1)
                        {
                            JSONString.Append("\"" + Headervalue + "\":" + "\"" + Cellvalue + "\",");
                        }
                        else if (j == colCount - 1)
                        {
                            JSONString.Append("\"" + Headervalue + "\":" + "\"" + Cellvalue + "\"");
                        }
                    }
                    if (i == rowCount)
                    {
                        JSONString.Append("}");
                    }
                    else
                    {
                        JSONString.Append("},");
                    }
                }
            }
            JSONString.Append("]");

            #endregion Create Json Data

            return JSONString.ToString();
        }

        private ExcelSheet GenrateExcelObject(Excel._Worksheet worksheet)
        {
            string errorMassage = string.Empty;
            ExcelSheet excelSheet = new ExcelSheet();
            excelSheet.Name = worksheet.Name;

            Excel.Range xlRange = worksheet.UsedRange;

            int rowCount = xlRange.Rows.Count;
            int colCount = xlRange.Columns.Count;

            List<ExcelRow> excelRowList;
            ExcelRow excelRowHeader;
            ExcelCell excelCell;
            List<ExcelCell> excelCellListForHeader;
            ExcelRow excelRow;

            #region Create Excel Sheet

            int validationFailRow = 0;
            if (rowCount > 2 && colCount > 1)
            {
                //CHECK HEADER
                if (excelValidator.ValidateHeader(xlRange, ref errorMassage))
                {
                    excelRowList = new List<ExcelRow>();

                    #region Header

                    //ExcelRow excelRowHeader = new ExcelRow();
                    excelRowHeader = new ExcelRow();

                    //List<ExcelCell> excelCellListForHeader = new List<ExcelCell>();
                    excelCellListForHeader = new List<ExcelCell>();
                    //CELL LOOP
                    for (int j = 1; j <= colCount; j++)
                    {
                        // ExcelCell excelCell = new ExcelCell();

                        excelCell = new ExcelCell();
                        string Headervalue;
                        if (xlRange.Cells[1, j] != null && xlRange.Cells[1, j].Value2 != null)
                            Headervalue = xlRange.Cells[1, j].Value2.ToString();
                        else
                            Headervalue = "";

                        excelCell.Value = Headervalue;
                        excelCell.HeaderName = Headervalue;

                        excelCellListForHeader.Add(excelCell);
                    }
                    ExcelCell excelHeaderCellCollection = new ExcelCell();
                    excelHeaderCellCollection.Value = "Remark";
                    excelCellListForHeader.Add(excelHeaderCellCollection);

                    excelRowHeader.isRowValidated = false;
                    excelRowHeader.CellCollection = excelCellListForHeader;
                    excelRowHeader.RowNumber = 0;
                    excelRowList.Add(excelRowHeader);

                    #endregion Header

                    #region Excel data

                    List<ExcelCell> excelCellList;
                    ExcelCell excelCellremark;
                    //ROW LOOP
                    for (int i = 2; i <= rowCount; i++)
                    {
                        //ExcelRow excelRow = new ExcelRow();
                        excelRow = new ExcelRow();
                        string errorMessage = string.Empty;

                        //List<ExcelCell> excelCellList = new List<ExcelCell>();
                        excelCellList = new List<ExcelCell>();
                        //CELL LOOP
                        for (int j = 1; j <= colCount; j++)
                        {
                            //ExcelCell excelCell = new ExcelCell();
                            excelCell = new ExcelCell();

                            string cellvalue;
                            if (xlRange.Cells[i, j] != null && xlRange.Cells[i, j].Value2 != null)
                                cellvalue = xlRange.Cells[i, j].Value2.ToString();
                            else
                                cellvalue = "";

                            string Headervalue;
                            if (xlRange.Cells[1, j] != null && xlRange.Cells[1, j].Value2 != null)
                                Headervalue = xlRange.Cells[1, j].Value2.ToString();
                            else
                                Headervalue = "";

                            excelCell.Value = cellvalue;
                            excelCell.HeaderName = Headervalue;

                            excelCellList.Add(excelValidator.ValidateCell(excelCell, ref errorMessage));
                        }

                        //Validate Row using Cell collection
                        excelCellList = excelValidator.ValidateRow(excelCellList, ref errorMessage);

                        //Create extra cell for remark
                        //ExcelCell excelCellremark = new ExcelCell();
                        excelCellremark = new ExcelCell();
                        excelCellremark.Value = errorMessage.Trim().Substring(0, (errorMessage.Trim().Length - 1) < 0 ? 0 : errorMessage.Trim().Length - 1);
                        excelCellList.Add(excelCellremark);

                        excelRow.CellCollection = excelCellList;
                        excelRow.isRowValidated = errorMessage.Trim() == "" ? true : false;
                        excelRow.RowNumber = i - 1;
                        excelRow.RowConclusion = "";

                        if (!excelRow.isRowValidated)
                            validationFailRow++;

                        excelRowList.Add(excelRow);
                    }
                    excelSheet.RowCollection = excelRowList;
                    excelSheet.SheetConclusion = "Total rows:" + (rowCount - 1) + ",Validated successful :" + (rowCount - 1 - validationFailRow) + " , failed :" + validationFailRow;

                    #endregion Excel data
                }
            }
            else
            {
                errorMassage = "Please upload right excel.";
            }

            #endregion Create Excel Sheet

            excelSheet.ErrorMassage = errorMassage;
            return excelSheet;
        }
    }
}