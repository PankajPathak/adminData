﻿using GSS1Hub.Shared.ExcelReader.Models;
using System.Collections.Generic;
using Excel = Microsoft.Office.Interop.Excel;

namespace GSS1Hub.Shared.ExcelReader
{
    public interface IExcelValidator
    {
        string DateFormat { get; set; }

        bool ValidateHeader(Excel.Range excelRange, ref string errorMsg);

        List<ExcelCell> ValidateRow(List<ExcelCell> listExcelCell, ref string errorMessage);

        ExcelCell ValidateCell(ExcelCell cell, ref string errorMessage);
    }
}