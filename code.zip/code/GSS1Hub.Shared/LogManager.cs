﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace GSS1Hub.Shared
{
    /// <summary>
    /// Writes different types of log to the configured log source
    /// </summary>
    public class LogManager
    {
        /// <summary>
        /// Defines the type of logs the log manager can handle
        /// </summary>
        public enum LogType
        {
            Error,
            Warning,
            Information
        }

        /// <summary>
        /// Writes the log
        /// </summary>
        /// <param name="typeOfLog">Log Type</param>
        /// <param name="log">Message to Log</param>
        public static void WriteLog(LogType typeOfLog, string log)
        {
            switch (typeOfLog)
            {
                case LogType.Error:
                    {
                        Trace.TraceError(log);
                        break;
                    }
                case LogType.Warning:
                    {
                        Trace.TraceWarning(log);
                        break;
                    }
                case LogType.Information:
                    {
                        Trace.TraceInformation(log);
                        break;
                    }
                    //default:
                    //    break;
            }
        }
    }
}
