﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace GSS1Hub.Shared.Extensions
{
    public static class AdoHelper
    {
        public static object ConvertToSqlValue(this Nullable<DateTime> _this)
        {
            if (_this.HasValue)
            {
                return _this.Value;
            }
            else
            {
                return DBNull.Value;
            }
        }

        public static object ConvertToSqlValue(this Nullable<long> _this)
        {
            if (_this.HasValue)
            {
                return _this.Value;
            }
            else
            {
                return DBNull.Value;
            }
        }

        public static object ConvertToSqlValue(this Nullable<bool> _this)
        {
            if (_this.HasValue)
            {
                return _this.Value;
            }
            else
            {
                return DBNull.Value;
            }
        }

        public static object ExecuteScaler(this DbContext _dbContext, string ProcedureName, object Parameter)
        {
            var connection = _dbContext.Database.Connection;
            try
            {
                connection.Open();
                var command = connection.CreateCommand();
                StringBuilder commandBuilder = new StringBuilder();//
                command.CommandText = ProcedureName;
                Type myType = Parameter.GetType();
                IList<PropertyInfo> props = new List<PropertyInfo>(myType.GetProperties());
                foreach (PropertyInfo prop in props)
                {
                    if (!prop.PropertyType.Name.Contains("IEnumerable`1"))
                    {
                        object propValue = prop.GetValue(Parameter, null);
                        DbParameter param = command.CreateParameter();
                        param.ParameterName = "@" + prop.Name;
                        param.Value = propValue;
                        command.Parameters.Add(param);
                    }
                    //commandBuilder.AppendFormat($"{param.ParameterName} ");
                    // Do something with propValue
                }

                command.CommandType = System.Data.CommandType.StoredProcedure;
                return command.ExecuteScalar();
            }
            finally
            {
                connection.Close();
                SqlConnection.ClearPool((SqlConnection)connection);
            }

        }
        public static bool ProcessMultipleRecord(this DbContext _dbContext, string procedureName, IEnumerable<object> parameters)
        {
            var connection = _dbContext.Database.Connection;
            connection.Open();
            DbTransaction dbTransaction = connection.BeginTransaction();
            try
            {
                foreach (object parameter in parameters)
                {
                    var command = connection.CreateCommand();
                    StringBuilder commandBuilder = new StringBuilder();//
                    command.CommandText = procedureName;
                    command.Transaction = dbTransaction;
                    Type myType = parameter.GetType();
                    IList<PropertyInfo> props = new List<PropertyInfo>(myType.GetProperties());
                    foreach (PropertyInfo prop in props)
                    {
                        object propValue = prop.GetValue(parameter, null);
                        DbParameter param = command.CreateParameter();
                        param.ParameterName = "@" + prop.Name;

                        if (!prop.PropertyType.IsEnum)
                        {
                            param.Value = propValue;
                        }
                        else
                        {
                            param.Value = (int)propValue;
                        }
                        command.Parameters.Add(param);
                        //commandBuilder.AppendFormat($"{param.ParameterName} ");
                        // Do something with propValue
                    }
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    long Id = (long)command.ExecuteScalar();
                    if (Id > 0)
                    {
                        continue;
                    }
                    else
                    {
                        dbTransaction.Rollback();
                        return false;
                    }
                }
                dbTransaction.Commit();
                //  connection.Close();
                SqlConnection.ClearPool((SqlConnection)connection);
                return true;
            }
            catch (Exception ex)
            {
                dbTransaction.Rollback();
                // connection.Close();
                SqlConnection.ClearPool((SqlConnection)connection);
                return false;
                throw ex;
            }
            finally
            {
                connection.Close();
            }
        }
    }
}
