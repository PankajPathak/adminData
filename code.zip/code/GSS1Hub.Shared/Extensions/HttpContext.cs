﻿using GSS1Hub.Shared.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSS1Hub.Shared.Extensions
{
    public static class HttpContext
    {
        public static RequestContext GetCurrentRequest(this System.Web.HttpContext requestContext)
        {
            RequestContext currentContext = null;
            string token = requestContext.Request.Headers.Get(Constants.RequestHeaders.AUTH_TOKEN);

            if (string.IsNullOrWhiteSpace(token))
            {
                System.Web.HttpCookie tokenCookie = requestContext.Request.Cookies[Constants.RequestHeaders.AUTH_TOKEN];
                if (tokenCookie != null) { token = tokenCookie.Value; }
                // LogManager.WriteLog(LogManager.LogType.Warning, "Token from cookie.");
            }

            if (!String.IsNullOrWhiteSpace(token))
            {
                currentContext = new ApplicationContext().Session.GetSessionData(token);
            }
            else
            {
                //if (Convert.ToString(requestContext.Request.RequestContext.RouteData.Values["controller"]) != "Account" && Convert.ToString(requestContext.Request.RequestContext.RouteData.Values["action"].ToString()) != "Login") {
                if (!requestContext.Response.IsRequestBeingRedirected)
                {
                    requestContext.Response.Redirect($"~/Account/Login?redirect={requestContext.Request.Url.PathAndQuery}", true);
                }
                //}
                //   LogManager.WriteLog(LogManager.LogType.Error, "Empty Token recieved." + token);
            }
            //if (currentContext == null)
            //{
            //    requestContext.Response.Clear();
            //    requestContext.Response.Redirect("Account/Login");
            //    requestContext.Response.End();
            //}
            // TODO: Redirect To Login Page
            //if (currentContext == null)
            //{
            //    LogManager.WriteLog(LogManager.LogType.Error, "Null context for token " + token);
            //    throw new InvalidOperationException("Invalid authentication token or session expired.");
            //}

            return currentContext;
        }

        //commented because no need
        //public static string GetLanguageId(this System.Web.HttpContext requestContext)
        //{
        //    string langCode = requestContext.Request.Headers.Get(Constants.RequestHeaders.LANGUAGE_ID);
        //    if (String.IsNullOrWhiteSpace(langCode))
        //    {
        //        System.Web.HttpCookie langCookie = requestContext.Request.Cookies[Constants.RequestHeaders.LANGUAGE_ID];
        //        if (langCookie != null)
        //        {
        //            langCode = langCookie.Value;
        //        }
        //    }
        //    if (String.IsNullOrWhiteSpace(langCode)) { langCode = String.Empty; }
        //    return langCode;
        //}

        public static string GetAuthToken(this System.Web.HttpContext requestContext)
        {
            string token = requestContext.Request.Headers.Get(Constants.RequestHeaders.AUTH_TOKEN);

            if (string.IsNullOrWhiteSpace(token))
            {
                System.Web.HttpCookie tokenCookie = requestContext.Request.Cookies[Constants.RequestHeaders.AUTH_TOKEN];
                if (tokenCookie != null) { token = tokenCookie.Value; }
                LogManager.WriteLog(LogManager.LogType.Warning, "Token from cookie.");
            }

            return token;
        }
    }
}
