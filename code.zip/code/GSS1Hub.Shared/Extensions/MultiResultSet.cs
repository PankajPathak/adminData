﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Text;

namespace GSS1Hub.Shared.Extensions
{
    public static class MultiResultSet
    {
        public static MultipleResultSetWrapper MultipleResults(this DbContext db, string storedProcedureName, object Parameter)
        {
            return new MultipleResultSetWrapper(db, storedProcedureName, Parameter);
        }

        public class MultipleResultSetWrapper
        {
            private readonly DbContext _db;
            private readonly object _Parameter;
            private readonly string _storedProcedure;
            public List<Func<IObjectContextAdapter, DbDataReader, IEnumerable>> _resultSets;

            public MultipleResultSetWrapper(DbContext db, string storedProcedureName, object Parameter)
            {
                _db = db;
                _Parameter = Parameter;
                _storedProcedure = storedProcedureName;
                _resultSets = new List<Func<IObjectContextAdapter, DbDataReader, IEnumerable>>();
            }

            public MultipleResultSetWrapper With<TResult>()
            {
                _resultSets.Add((adapter, reader) => adapter
                    .ObjectContext
                    .Translate<TResult>(reader)
                    .ToList());

                return this;
            }

            public List<IEnumerable> Execute()
            {
                var results = new List<IEnumerable>();
                var connection = _db.Database.Connection;
                connection.Open();
                try
                {
                    var command = connection.CreateCommand();
                    StringBuilder commandBuilder = new StringBuilder();//
                    command.CommandText = _storedProcedure;
                    Type myType = _Parameter.GetType();
                    IList<PropertyInfo> props = new List<PropertyInfo>(myType.GetProperties());
                    foreach (PropertyInfo prop in props)
                    {
                        object propValue = prop.GetValue(_Parameter, null);
                        DbParameter param = command.CreateParameter();
                        param.ParameterName = "@" + prop.Name;
                        param.Value = propValue;
                        command.Parameters.Add(param);
                        //commandBuilder.AppendFormat($"{param.ParameterName} ");
                        //Do something with propValue
                    }

                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    using (var reader = command.ExecuteReader())
                    {
                        var adapter = ((IObjectContextAdapter)_db);
                        foreach (var resultSet in _resultSets)
                        {
                            results.Add(resultSet(adapter, reader));
                            reader.NextResult();
                        }
                    }
                    return results;
                }
                finally
                {
                    connection.Close();
                    SqlConnection.ClearPool((SqlConnection)connection);
                }
            }


        }

        public static DataSet ReadResult(this DbContext db, string procedureName, params SqlParameter[] parameters)
        {
            DataSet returnDs = new DataSet();
            DbCommand cmd = db.Database.Connection.CreateCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = procedureName;
            using (SqlConnection con = new SqlConnection(db.Database.Connection.ConnectionString))
            {
                SqlDataAdapter adp = new SqlDataAdapter(procedureName, con);
                adp.SelectCommand.CommandType = CommandType.StoredProcedure;
                adp.SelectCommand.Parameters.AddRange(parameters);
                adp.Fill(returnDs);
            }

            return returnDs;
        }

        public static DataSet ReadData(this DbContext db, string procedureName, params SqlParameter[] parameters)
        {
            DataSet returnDs = new DataSet();
            DbCommand cmd = db.Database.Connection.CreateCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = procedureName;
            cmd.Parameters.AddRange(parameters);
            if (cmd.Connection.State == ConnectionState.Closed) { cmd.Connection.Open(); }

            DbDataReader reader = cmd.ExecuteReader(CommandBehavior.Default);

            do
            {
                DataTable dt = new DataTable();
                dt.Load(reader);
                returnDs.Tables.Add(dt);
            }
            while (reader.IsClosed == false && reader.NextResult());

            //while (true)
            //{
            //    DataTable dt = new DataTable();
            //    dt.Load(reader);
            //    returnDs.Tables.Add(dt);
            //    if (!reader.IsClosed)
            //    {
            //       reader.NextResult
            //    }
            //    else
            //    {
            //        break;
            //    }
            //}

            if (cmd.Connection.State == ConnectionState.Open) { cmd.Connection.Close(); }

            return returnDs;
        }
    }
}
