﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.IO;

namespace GSS1Hub.Shared
{
    public static class DtToXml
    {
        public static string ConvertToXML(DataTable dt)
        {
            DataTable dtCloned = dt.Clone();
            foreach (DataColumn dc in dtCloned.Columns)
                dc.DataType = typeof(string);
            foreach (DataRow row in dt.Rows)
            {
                dtCloned.ImportRow(row);
            }

            foreach (DataRow row in dtCloned.Rows)
            {
                for (int i = 0; i < dtCloned.Columns.Count; i++)
                {
                    dtCloned.Columns[i].ReadOnly = false;

                    if (string.IsNullOrEmpty(row[i].ToString()))
                        row[i] = string.Empty;
                }
            }
            MemoryStream str = new MemoryStream();
            dtCloned.TableName = "XMLData";
            dtCloned.WriteXml(str, XmlWriteMode.WriteSchema,true);
            str.Seek(0, SeekOrigin.Begin);
            StreamReader sr = new StreamReader(str);

            return sr.ReadToEnd();
        }
    }
}
