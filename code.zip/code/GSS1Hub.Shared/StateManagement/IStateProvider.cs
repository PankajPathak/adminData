﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GSS1Hub.Shared.Model;

namespace GSS1Hub.Shared.StateManagement
{
    public interface IStateProvider
    {
        /// <summary>
        /// Adds the request context object to session dictionary.
        /// </summary>
        /// <param name="sessionData">Sesion Data to store</param>
        /// <returns>Authorization Token. it will be used to access the object back.</returns>
        string AddSession(RequestContext sessionData, int timeZoneOffset);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        RequestContext GetSessionData(string key);

        bool RemoveSession(string key);
        /// <summary>
        /// Need to update this modal of the context due to drop down changes
        /// </summary>
        /// <param name="sessionData"></param>
        /// <param name="sessionKey"></param>
        /// <returns></returns>
        string UpdateSession(RequestContext sessionData, string sessionKey);
    }
}
