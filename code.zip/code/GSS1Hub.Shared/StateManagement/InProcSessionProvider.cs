﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GSS1Hub.Shared.Model;

namespace GSS1Hub.Shared.StateManagement
{
    public class InProcSessionProvider : IStateProvider
    {
        private static readonly ConcurrentDictionary<string, RequestContext> Sessions = null;
        static InProcSessionProvider()
        {
            InProcSessionProvider.Sessions = new ConcurrentDictionary<string, RequestContext>();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sessionData"></param>
        /// <returns></returns>
        public string AddSession(RequestContext sessionData, int timeZoneOffset)
        {
            string sessionKey = Guid.NewGuid().ToString();
            InProcSessionProvider.Sessions.AddOrUpdate(sessionKey, sessionData, (k, v) => sessionData);
            return sessionKey;
        }

        public RequestContext GetSessionData(string key)
        {
            RequestContext context = null;
            if (InProcSessionProvider.Sessions.ContainsKey(key))
            {
                context = InProcSessionProvider.Sessions[key];
            }
            else
            {
                LogManager.WriteLog(LogManager.LogType.Error, "Token Not Found for key: " + key + " Key count: " + InProcSessionProvider.Sessions.Count);
                //throw new SessionNotFoundException("Your Session Expired, Please login again");
            }

            return context;
        }

        public bool RemoveSession(string key)
        {
            RequestContext val;
            return InProcSessionProvider.Sessions.TryRemove(key, out val);
        }

        public string UpdateSession(RequestContext sessionData, string sessionKey)
        {
            InProcSessionProvider.Sessions.AddOrUpdate(sessionKey, sessionData, (k, v) => sessionData);
            return sessionKey;
        }
    }
}
