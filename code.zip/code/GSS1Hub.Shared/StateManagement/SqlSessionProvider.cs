﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GSS1Hub.Shared.Model;
using System.Data.SqlClient;
using GSS1Hub.Shared.Constants;
using GSS1Hub.Shared.Extensions;
namespace GSS1Hub.Shared.StateManagement
{
    public class SqlSessionProvider : IStateProvider
    {
        private static readonly ConcurrentDictionary<string, RequestContext> Sessions = null;

        static SqlSessionProvider()
        {
            SqlSessionProvider.Sessions = new ConcurrentDictionary<string, RequestContext>();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sessionData"></param>
        /// <returns></returns>
        public string AddSession(RequestContext sessionData, int timeZoneOffset)
        {

            string sessionKey = Guid.NewGuid().ToString();
            SqlSessionProvider.Sessions.AddOrUpdate(sessionKey, sessionData, (k, v) => sessionData); 
            // TODO: Call Stored Procedure to save the session key along with user detail in database
            using (GSS1HubContext context = new GSS1HubContext())
            {
                var rowsAffected = context.Database.SqlQuery<DateTime>(GSS1HubSP.GSS1Hub_InsertOrUpdateUserSession + "@SessionId, @UserId, @DelegationUserId, @timeZoneOffset",
                    new SqlParameter("@SessionId", sessionKey),
                    new SqlParameter("@UserId", sessionData.UserDetail.Id),
                    new SqlParameter("@DelegationUserId", sessionData.DelegatedUserDetail != null ? sessionData.DelegatedUserDetail.Id : Convert.ToInt64(0)),
                   new SqlParameter("@timeZoneOffset", timeZoneOffset)).ToList();
                if (rowsAffected.Count > 0)
                {
                    sessionData.LoggedOn = rowsAffected.FirstOrDefault();
                    // TODO: Get Session detil from Database and add it to SqlSessionProvider.Sessions
                    // LogManager.WriteLog(LogManager.LogType.Error, "AddSession: " + key + " Key count: " + SqlSessionProvider.Sessions.Count);
                    //throw new SessionNotFoundException("Your Session Expired, Please login again");
                }

            }
            return sessionKey;
        }

        public RequestContext GetSessionData(string key)
        {
            RequestContext context = null;
            if (SqlSessionProvider.Sessions.ContainsKey(key))
            {
                context = SqlSessionProvider.Sessions[key];

            }
            else
            {
                // TODO: Get Session detil from Database and add it to SqlSessionProvider.Sessions
                List<UserSession> lstUserSession = new List<UserSession>();
                long userId = 0;
                using (GSS1HubContext cxt = new GSS1HubContext())
                {
                    lstUserSession = cxt.Database.SqlQuery<UserSession>(GSS1HubSP.GSS1Hub_GetUserSession + "@SessionId", new SqlParameter("@SessionId", key)).ToList();
                    if (lstUserSession.Count > 0)
                    {
                        context = new RequestContext();
                        context.LoggedOn = lstUserSession[0].LoggedOn;
                        //if (lstUserSession[0].DelegationUserId == 0)
                        //{
                        //    userId = lstUserSession[0].DelegationUserId;
                        //}
                        //else
                        //{
                        //    userId = lstUserSession[0].UserId;
                        //}

                        userId = lstUserSession[0].UserId;

                        var result = cxt.MultipleResults(GSS1HubSP.GSS1Hub_AuthenticateUserByUserId, new { UserId = userId })
                            .With<UserDetail>().
                            With<BizflowDetail>().Execute();
                        if (result.Count > 0)
                        {
                            context.UserDetail = (((IEnumerable<UserDetail>)result[0]).FirstOrDefault() == null) ? new UserDetail() : ((IEnumerable<UserDetail>)result[0]).FirstOrDefault() as UserDetail;
                            context.BizflowDetails = (IEnumerable<BizflowDetail>)result[1];

                            if (lstUserSession[0].DelegationUserId > 0) {
                                context.DelegatedUserDetail = new UserDetail { Id = lstUserSession[0].DelegationUserId };
                            }
                            

                            //if (lstUserSession[0].DelegationUserId == 0)
                            //{
                            //    context.UserDetail = (((IEnumerable<UserDetail>)result[0]).FirstOrDefault() == null) ? new UserDetail() : ((IEnumerable<UserDetail>)result[0]).FirstOrDefault() as UserDetail;
                            //}
                            //else
                            //{
                            //    context.DelegatedUserDetail = (((IEnumerable<UserDetail>)result[0]).FirstOrDefault() == null) ? new UserDetail() : ((IEnumerable<UserDetail>)result[0]).FirstOrDefault() as UserDetail;
                            //}

                        }
                        SqlSessionProvider.Sessions.AddOrUpdate(lstUserSession[0].SessionId, context, (k, v) => context);
                    }
                }
            }
            return context;
        }

        public bool RemoveSession(string key)
        {
            bool IsRemove = false;
            RequestContext val;
            SqlSessionProvider.Sessions.TryRemove(key, out val);
            using (GSS1HubContext cxt = new GSS1HubContext())
            {
                var result = cxt.Database.SqlQuery<int>(GSS1HubSP.GSS1Hub_RemoveUserSession + "@SessionId", new SqlParameter("@SessionId", key)).FirstOrDefault();
                if (result == 1)
                { IsRemove = true; }
            }

            return IsRemove;

        }

        public string UpdateSession(RequestContext sessionData, string sessionKey)
        {
            SqlSessionProvider.Sessions.AddOrUpdate(sessionKey, sessionData, (k, v) => sessionData);
            return sessionKey;
        }
    }
}
