﻿using GSS1Hub.Shared.StateManagement;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSS1Hub.Shared
{
    public sealed class ApplicationContext
    {
        public IStateProvider Session
        {
            get
            {
                return new SqlSessionProvider();
            }
        }

    }
}
