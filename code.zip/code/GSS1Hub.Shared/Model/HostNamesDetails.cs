﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace GSS1Hub.Shared.Model
{
    [DataContract]
    public class HostNamesDetails 
    {
        [DataMember]
        public long Id { get; set; }

        [DataMember]
        public string HostName { get; set; }
        [DataMember]
        public string SerialNo { get; set; }
        [DataMember]
        public string Location { get; set; }
        [DataMember]
        public string AssetType { get; set; }
        [DataMember]
        public string Make { get; set; }
        [DataMember]
        public string Model { get; set; }
        [DataMember]
        public string AssetTag { get; set; }

        [DataMember]
        public long ActiveStatusId { get; set; }
        [DataMember]
        public long Created_By { get; set; }
        [DataMember]
        public DateTime Created_On { get; set; }
        [DataMember]
        public long Updated_By { get; set; }
        [DataMember]
        public DateTime Updated_On { get; set; }
    }

}
