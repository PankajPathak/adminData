﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSS1Hub.Shared.Model.Enumeration
{
    public enum InComingType
    {
        SubmitForApproval,
        Forward,
        Save,
        Approval,
        Clarification,
        ClarificationSubmit,
        Update,
        Discard,
        SaveAsDraft
    }
}
