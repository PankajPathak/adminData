﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace GSS1Hub.Shared.Model
{
    [DataContract]
    public class UserSessionDetails
    {
        [DataMember]
        public UserDetail UserDetail { get; set; }
        [DataMember]
        public IEnumerable<BizflowDetail> BizflowDetails { get; set; }
    }
}
