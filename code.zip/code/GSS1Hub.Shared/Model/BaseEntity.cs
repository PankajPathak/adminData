﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using GSS1Hub.Shared.Extensions;

namespace GSS1Hub.Shared.Model
{
    [DataContract]
    public class BaseEntity
    {
        private long? _userId = null;
        public BaseEntity()
        {   }

        [DataMember]
        public long Id { get; set; }

        [DataMember]
        public long UserId
        {
            get
            {
                if (this._userId != null)
                {
                    return this._userId.Value;
                }
                else
                {
                    RequestContext context = System.Web.HttpContext.Current.GetCurrentRequest();
                    if (context != null && context.UserDetail != null && context.UserDetail.Id > 0)
                    {
                        return context.UserDetail.Id;
                    }
                    else
                    {
                        return 0;
                    }
                }
            }

            set
            {
                this._userId = value;
            }
        }

        [DataMember]
        public bool IsInactive { get; set; }

        [DataMember]
        public short ActiveStatusId { get; set; }
        [DataMember]
        public long CreatedBy { get; set; }
        [DataMember]
        public DateTime CreatedOn { get; set; }
        [DataMember]
        public long? UpdatedBy { get; set; }
        [DataMember]
        public DateTime? UpdatedOn { get; set; }

    }
}
