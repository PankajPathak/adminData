﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSS1Hub.Shared.Model
{
    public class UserPreferences : LanguageSetting
    {
        public UserPreferences()
        {

        }
        public UserPreferences(LanguageSetting setting) : base (setting)
        {
           
        }
        public List<TimeZone> TimeZones { get; set; }

        public TimeZone UserTimeZone { get; set; }
    }
}
