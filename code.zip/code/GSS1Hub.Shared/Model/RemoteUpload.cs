﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Diagnostics;

namespace GSS1Hub.Models
{
    public abstract class RemoteUpload
    {
        public string FileName
        {
            get;
            set;
        }
        public string UrlString
        {
            get;
            set;
        }
        public string NewFileName
        {
            get;
            set;
        }
        public byte[] FileData
        {
            get;
            set;
        }
        public RemoteUpload(byte[] fileData, string fileName, string urlString)
        {
            Trace.Write("Inside remote upload");
            this.FileData = fileData;
            this.FileName = fileName;
            this.UrlString = urlString.EndsWith("/") ? urlString : urlString + "/";
            Trace.Write("Inside remote upload url" + this.UrlString);
            string newFileName = DateTime.Now.ToString("yyMMddhhmmss")
                        + DateTime.Now.Millisecond.ToString()
                       + Path.GetExtension(this.FileName);
            this.UrlString = this.UrlString + fileName;//newFileName;
            Trace.Write("Inside remote upload fileName" + this.UrlString);
        }
        /// <summary>
        /// upload file to remote server
        /// </summary>
        /// <returns></returns>
        public virtual bool UploadFile()
        {
            return true;
        }

    }

    /// <summary>
    /// HttpUpload class
    /// </summary>
    public class HttpRemoteUpload : RemoteUpload
    {

        string _strAccessID = ConfigurationManager.AppSettings["QV_UploadAccessFunctionalID"].ToString().TrimStart().TrimEnd();
        string _strAccessPWD = ConfigurationManager.AppSettings["QV_UploadAccessFunctionalPwd"].ToString().TrimStart().TrimEnd();
        string _strAccessDomain = ConfigurationManager.AppSettings["QV_UploadAccessDomain"].ToString().TrimStart().TrimEnd();
        public HttpRemoteUpload(byte[] fileData, string fileNamePath, string urlString)
            : base(fileData, fileNamePath, urlString)
        {

        }

        public override bool UploadFile()
        {

            byte[] postData;
            try
            {
                postData = this.FileData;

                using (WebClient client = new WebClient())
                {

                    // client.Credentials = CredentialCache.DefaultCredentials;
                    client.Credentials = new System.Net.NetworkCredential(_strAccessID.ToString().TrimStart().TrimEnd(), _strAccessPWD.ToString().TrimStart().TrimEnd(), _strAccessDomain.ToString().TrimStart().TrimEnd());//("AQ895002", "ubnig3iO", "metnet");
                                                                                                                                                                                                                            // string webpage = client.DownloadString(url);
                    client.Headers.Add("Content-Type", "application/x-www-form-urlencoded");
                    client.UploadData(this.UrlString, "PUT", postData);
                }

                return true;
            }
            catch (Exception ex)
            {
                return false;
                //ErrorLog(ex.GetType().ToString(), 8, ex.Message.ToString(), "RempteUpload Function File", "RemoteUpload.cs", Convert.ToDateTime(DateTime.Now), 0);
                throw new Exception("Failed to upload", ex.InnerException);
            }

        }


    }

    /// <summary>
    /// FtpUpload class
    /// </summary>
    public class FtpRemoteUpload : RemoteUpload
    {
        public FtpRemoteUpload(byte[] fileData, string fileNamePath, string urlString)
            : base(fileData, fileNamePath, urlString)
        {

        }

        public override bool UploadFile()
        {
            FtpWebRequest reqFTP;
            reqFTP = (FtpWebRequest)FtpWebRequest.Create(this.UrlString);
            reqFTP.KeepAlive = true;
            reqFTP.Method = WebRequestMethods.Ftp.UploadFile;
            reqFTP.UseBinary = true;
            reqFTP.ContentLength = this.FileData.Length;

            int buffLength = 2048;
            byte[] buff = new byte[buffLength];
            MemoryStream ms = new MemoryStream(this.FileData);

            try
            {
                int contenctLength;
            using (Stream strm = reqFTP.GetRequestStream())
            {
                contenctLength = ms.Read(buff, 0, buffLength);
                while (contenctLength > 0)
                {
                    strm.Write(buff, 0, contenctLength);
                    contenctLength = ms.Read(buff, 0, buffLength);
                }
            }

            return true;
            }
            catch (Exception ex)
            {

                // ErrorLog(ex.GetType().ToString(), 8, ex.Message.ToString(), "RempteUpload Function File", "RemoteUpload.cs", Convert.ToDateTime(DateTime.Now), 0);
                throw new Exception("Failed to upload", ex.InnerException);
            }
        }

    }
}