﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSS1Hub.Shared.Model.ViewModel
{
    public class BuNodes
    {
        public long Id { get; set; }

        public List<OuNode> OuTree { get; set; }
    }
}
