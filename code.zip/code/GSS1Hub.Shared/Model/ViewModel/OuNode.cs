﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace GSS1Hub.Shared.Model.ViewModel
{
    [DataContract]
    public class OuNode
    {
        [DataMember]
        public long id { get; set; }

        [DataMember]
        public string title { get; set; }

        //[DataMember]
        //public string owner { get; set; }

        //[DataMember]
        //public DateTime effectiveDate { get; set; }

        //[DataMember]
        //public int ccCode { get; set; }

        [DataMember]
        public OuNode[] nodes { get; set; }
    }
}
