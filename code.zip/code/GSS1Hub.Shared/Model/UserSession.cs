﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace GSS1Hub.Shared.Model
{
    [DataContract]
    public class UserSession : BaseEntity
    {
        [DataMember]
        public string SessionId { get; set; }
        [DataMember]        
        public DateTime LoggedOn { get; set; }

        [DataMember]
        public DateTime? LoggedOut { get; set; }
        [DataMember]
        public long DelegationUserId { get; set; }


    }
}
