﻿using GSS1Hub.Shared.Model.Enumeration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace GSS1Hub.Shared.Model
{
    [DataContract]
    public class ApiResult<T>
    {
        public ApiResult()
        {
            this.Code = "200";
            this.Message = "Success";
            this.Status = ResponseStatus.Success;
        }
        [DataMember]
        public long Id { get; set; }
        [DataMember]
        public string Code { get; set; }

        [DataMember]
        public string Message { get; set; }
        [DataMember]
        public ResponseStatus Status { get; set; }
        [DataMember]
        public T Data { get; set; }
    }
}
