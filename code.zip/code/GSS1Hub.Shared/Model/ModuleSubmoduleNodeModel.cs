﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace GSS1Hub.Shared.Model
{
    [DataContract]
    public class ModuleSubmoduleNodeModel
    {
        [DataMember]
        public long Id { get; set; }

        [DataMember]
        public string Title { get; set; }

        [DataMember]
        public bool? Create { get; set; }

        [DataMember]
        public bool? Read { get; set; }

        [DataMember]
        public bool? Edit { get; set; }

        [DataMember]
        public bool? Delete { get; set; }

        [DataMember]
        public bool? IsSelected { get; set; }

        [DataMember]
        public bool? IsRoot { get; set; }

        [DataMember]
        public long? PId { get; set; }

        [DataMember]
        public long? FRId { get; set; }

        [DataMember]
        public string ModuleUrl { get; set; }



        [DataMember]
        public List<ModuleSubmoduleNodeModel> nodes = new List<ModuleSubmoduleNodeModel>();

    }
}
