﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSS1Hub.Shared.Model
{
    public class LanguageSetting
    {
        public LanguageSetting()
        {

        }

        public LanguageSetting(LanguageSetting settings)
        {
            this.Languages = settings.Languages;
            this.PrefferedLanguage = settings.PrefferedLanguage;
        }
        public IEnumerable<Language> Languages { get; set; }

        public Language PrefferedLanguage { get; set; }
    }
}
