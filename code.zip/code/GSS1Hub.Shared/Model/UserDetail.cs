﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace GSS1Hub.Shared.Model
{
    [DataContract]
    public class UserDetail
    {
        [DataMember]
        public long Id { get; set; }

        [DataMember]
        public long EmployeeId { get; set; }
        [DataMember]
        public string FirstName { get; set; }
        [DataMember]
        public string LastName { get; set; }
        [DataMember]
        public string Email { get; set; }
        [DataMember]
        public string MetnetId { get; set; }
        [DataMember]
        public long UserLanguageId { get; set; }

        [DataMember]
        public string UserLanguageCode { get; set; }
        [DataMember]
        public long ActiveStatusId { get; set; }
        [DataMember]
        public long Created_By { get; set; }
        [DataMember]
        public DateTime Created_On { get; set; }
        [DataMember]
        public long Updated_By { get; set; }
        [DataMember]
        public DateTime Updated_On { get; set; }
        [DataMember]
        public string ImagePath { get; set; }
        [DataMember]
        public long EntityId { get; set; }
        [DataMember]
        public string Location { get; set; }
    }
}
