﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace GSS1Hub.Shared.Model
{
    [DataContract]
    public class NodeItem
    {
        public NodeItem()
        {
            this.nodes = new List<NodeItem>();
        }

        [DataMember]
        public long id { get; set; }

        [DataMember]
        public string title { get; set; }

        [DataMember]
        public bool IsSelected { get; set; }

        [DataMember]
        public long OuTabId { get; set; }

        [DataMember]
        public Int16 IsLI { get; set; }

        [DataMember]
        public string BudgetType { get; set; }

        [DataMember]
        public string ModuleUrl { get; set; }

        [DataMember]
        public string TemplateUrl { get; set; }

        [DataMember]
        public List<NodeItem> nodes { get; set; }
    }
}
