﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace GSS1Hub.Shared.Model
{
    [DataContract]
    public class InputDefaultTableReport
    {
        [DataMember]
        public int PageNumber { get; set; }
        [DataMember]
        public int PageSize { get; set; }
        [DataMember]
        public string SearchText1 { get; set; }
        [DataMember]
        public int SearchTextOperator { get; set; }
        [DataMember]
        public string SearchText2 { get; set; }
        [DataMember]
        public long UserId { get; set; }
    }
}
