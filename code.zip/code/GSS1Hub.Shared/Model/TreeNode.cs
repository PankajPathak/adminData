﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace GSS1Hub.Shared.Model
{
    [DataContract]
    public class TreeNode
    {
        public TreeNode()
        {
            this.nodes = new List<TreeNode>();
        }

        [DataMember]
        public long id { get; set; }

        [DataMember]
        public long ProgramId { get; set; }

        [DataMember]
        public string ProgramName { get; set; }

        [DataMember]
        public string ProgramDescription { get; set; }

        [DataMember]
        public long? ParentProgramId { get; set; }

        [DataMember]
        public string ModuleUrl { get; set; }

        [DataMember]
        public string TemplateUrl { get; set; }

        [DataMember]
        public List<TreeNode> nodes { get; set; }
    }
    
}
