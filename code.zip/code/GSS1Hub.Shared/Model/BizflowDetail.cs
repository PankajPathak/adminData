﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace GSS1Hub.Shared.Model
{
    [DataContract]
    public class BizflowDetail
    {
        [DataMember]
        public long GroupMasterId { get; set; }
        [DataMember]
        public string GroupName { get; set; }
        [DataMember]
        public string GroupLoginId { get; set; }
        [DataMember]
        public string EncryptedPassword { get; set; }
    }
}
