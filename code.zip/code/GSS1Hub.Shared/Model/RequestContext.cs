﻿using GSS1Hub.Shared.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace GSS1Hub.Shared.Model
{
    [DataContract]
    public class RequestContext
    {
        public RequestContext()
        {
            this.UserDetail = new UserDetail();
            this.BizflowDetails = new List<BizflowDetail>();
        }
        [DataMember]
        public DateTime LoggedOn { get; set; }

        [DataMember]
        public UserDetail UserDetail { get; set; }

        public UserDetail DelegatedUserDetail { get; set; }

        [DataMember]
        public IEnumerable<BizflowDetail> BizflowDetails { get; set; }
    }
}
