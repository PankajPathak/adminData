﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSS1Hub.Shared.Constants
{
    public sealed class RequestHeaders
    {
        public const string AUTH_TOKEN = "auth-token";

        public const string LANGUAGE_ID = "clang";

        public const string ROOT_URL = "root";
    }
}
