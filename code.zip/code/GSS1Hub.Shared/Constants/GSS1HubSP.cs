﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSS1Hub.Shared.Constants
{
    /// <summary>
    /// 
    /// </summary>
    public sealed class GSS1HubSP
    {

        public const string GSS1Hub_AuthenticateUserByMetnetId = "[GSS1Hub_AuthenticateUserByMetnetId]";

        public const string GSS1Hub_AuthenticateUserByUserId = "[GSS1Hub_AuthenticateUserByUserId]";

        public const string GSS1Hub_GetModuleListByEmployeeId = "[GSS1Hub_GetModuleListByEmployeeId]";

        //public const string GSS1Hub_GetModules = "[GSS1Hub_GetModules]";

        public const string GSS1Hub_GetFieldValidation = "[GSS1Hub_GetFieldValidation]";

        public const string GSS1Hub_GetFieldValidationByForm = "[GSS1Hub_GetFieldValidationByForm]";

        public const string GSS1Hub_UpdateFieldValidation = "[GSS1Hub_UpdateFieldValidation]";

        //public const string GSS1Hub_UpdateUserLanguage = "[GSS1Hub_UpdateUserLanguage]";

        public const string GSS1Hub_GetLanguages = "[GSS1Hub_GetLanguages]";

        public const string GSS1Hub_GetLoggedUserLanguage = "[GSS1Hub_GetLoggedUserLanguage]";

        public const string GSS1Hub_GetUserModules_scheduleMaster_notificationMaster = "[GSS1Hub_GetUserModules_scheduleMaster_notificationMaster]";

        public const string GSS1Hub_InsertOrUpdateEmailConfiguration = "[GSS1Hub_InsertOrUpdateEmailConfiguration]";

        //public const string GSS1Hub_GetAllGroupUserMap = "[GSS1Hub_GetAllGroupUserMap]";

        //public const string GSS1Hub_InsertOrUpdateGroupUserMapMaster = "[GSS1Hub_InsertOrUpdateGroupUserMapMaster]";

        public const string GSS1Hub_GetListOfValuesByCodeAndMasterCodeAndMasterValue = "[GSS1Hub_GetListOfValuesByCodeAndMasterCodeAndMasterValue]";

        public const string GSS1Hub_GetListOfValuesByModuleAndCodeAndMasterCodeAndMasterValue = "[GSS1Hub_GetListOfValuesByModuleAndCodeAndMasterCodeAndMasterValue]";
        
        public const string GSS1Hub_GetListOfValuesByCode = "[GSS1Hub_GetListOfValuesByCode] @Code";

        public const string GetEntityMasterOrProgramMasterByType = "[GetEntityMasterOrProgramMasterByType] @Type, @Id";

        public const string GSS1Hub_GetAutoComplete = "[GSS1Hub_GetAutoComplete]";

        //public const string GSS1Hub_GetAutoCompleteForGroupUserMaster = "[GSS1Hub_GetAutoCompleteForGroupUserMaster]";

        public const string GSS1Hub_GetAllGroupMasterModuleMasterModuleGroupMap = "[GSS1Hub_GetAllGroupMasterModuleMasterModuleGroupMap]";

        //public const string GSS1Hub_InsertOrUpdateGroupModuleMapMaster = "[GSS1Hub_InsertOrUpdateGroupModuleMapMaster]";

        //public const string GSS1Hub_GetGroupMasterBySearchCriteria = "[GSS1Hub_GetGroupMasterBySearchCriteria]";

        //public const string GSS1Hub_GetUsersByGroupId = "[GSS1Hub_GetUsersByGroupId]";

        //public const string GSS1Hub_GetGroupsByModuleId = "[GSS1Hub_GetGroupsByModuleId]";

        //public const string GSS1Hub_GetModuleMasterBySearchCriteria = "[GSS1Hub_GetModuleMasterBySearchCriteria]";

        //public const string GSS1Hub_GetGroupMaster = "[GSS1Hub_GetGroupMaster]";

        public const string GSS1Hub_CheckGroupName = "[GSS1Hub_CheckGroupName]";

        public const string GSS1Hub_CheckdisplayNameForModulemaster = "[GSS1Hub_CheckdisplayNameForModulemaster]";

        

        //public const string GSS1Hub_InsertOrUpdateGroupMaster = "[GSS1Hub_InsertOrUpdateGroupMaster]";

        public const string GSS1Hub_GetGroupMasterById = "[GSS1Hub_GetGroupMasterById]";

        //public const string GSS1Hub_InsertOrUpdateModuleMaster = "[GSS1Hub_InsertOrUpdateModuleMaster]";

        public const string GSS1Hub_GetModulesById = "[GSS1Hub_GetModulesById]";

        //public const string GSS1Hub_GetTileStatuses = "[GSS1Hub_GetTileStatuses] @Values, @UserId";

        public const string GSS1Hub_GetAutoCompleteProcessProject = "[GSS1Hub_GetAutoCompleteProcessProject]";

        //public const string GSS1Hub_GetAllModuleNames = "[GSS1Hub_GetAllModuleNames]";

        //public const string GSS1Hub_GetUserDetailsByID = "[GSS1Hub_UserDetailsbyID]";

        public const string GSS1Hub_GetGroupModuleMasterBySearchCriteria = "[GSS1Hub_GetGroupModuleMasterBySearchCriteria]";

        public const string GSS1Hub_UpdateUserImage = "[GSS1Hub_UpdateUserImage]";

        

        public const string GSS1HUB_GetReportNames = "[GSS1HUB_GetReportNames]";

        public const string GSS1HUB_GetGroupReportNames = "[GSS1HUB_GetGroupReportNames]";

        public const string GSS1HUB_GetRptGrpmap = "[GSS1HUB_GetRptGrpmap]";

        public const string GSS1HUB_InsertGrpmap = "[GSS1HUB_InsertGrpmap]";

        public const string GSS1Hub_ReportDetails = "[GSS1Hub_ReportDetails]";

        public const string GSS1HUB_ExecuteReportQuery = "[GSS1HUB_ExecuteReportQuery]";

        public const string GSS1Hub_CheckAuthorizationByControllerAction = "[GSS1Hub_CheckAuthorizationByControllerAction]";

        public const string GSS1Hub_GetUserModule = "[GSS1Hub_GetUserModule]";

      //  public const string GSS1Hub_GetUserModule = "[GSS1Hub_GetUserModule_WithLanguage]";

        

        public const string Gss1Hub_GetTimeZones = "[Gss1Hub_GetTimeZones] @localTimeDiff, @userId";

        public const string Gss1Hub_UpdateTimeZone = "[Gss1Hub_UpdateTimeZone] @Token, @TimeZoneId";

        public const string GSS1Hub_GetLanguageMasterByCode = "[GSS1Hub_GetLanguageMasterByCode] @Code";

        public const string GSS1Hub_GetUserSession = "[GSS1Hub_GetUserSession]";

        //public const string GSS1Hub_InsertOrUpdateDelegateModule = "[GSS1Hub_InsertOrUpdateDelegateModule]";
        // public const string GSS1Hub_DTR_GetWorkingOrMasterProjectNameExistsOrNotByProjectName = "[GSS1Hub_DTR_GetWorkingOrMasterProjectNameExistsOrNotByProjectName]";

        //public const string GSS1Hub_GetModuleSubModule = "[GSS1Hub_GetModuleSubModule]";
        public const string GSS1Hub_GetSiteMapModuleURL = "[GSS1Hub_GetSiteMapModuleURL]";
        //public const string GSS1Hub_GetSiteMap = "[GSS1Hub_GetSiteMap]";

        //public const string GSS1Hub_GetDelegatedUsers = "[GSS1Hub_GetDelegatedUsers]";

        public const string GSS1Hub_GetDelegatedModulesByCreatedUser = "[GSS1Hub_GetDelegatedModulesByCreatedUser]";

        //public const string GSS1Hub_GetModuleswithrights = "[GSS1Hub_GetModuleswithrights]";

        //public const string GSS1HUB_InsertUserRights = "[GSS1HUB_InsertUserRights]";

        public const string GSS1Hub_RemoveUserSession = "[GSS1Hub_RemoveUserSession]";

        public const string GSS1Hub_InsertOrUpdateUserSession = "[GSS1Hub_InsertOrUpdateUserSession]";

        public const string GSS1Hub_GetLoginAttempt = "[GSS1Hub_GetLoginAttempt]";

        public const string GSS1Hub_UpdateLoginAttempt = "[GSS1Hub_UpdateLoginAttempt]";

        public const string GSS1Hub_GetAutoCompleteForDelgateModule = "[GSS1Hub_GetAutoCompleteForDelgateModule]";

        public const string GSS1Hub_SoftDeleteById = "[GSS1Hub_SoftDeleteById]";

        public const string GSS1Hub_UniqueValidator = "[GSS1Hub_UniqueValidator]";

        public const string GSS1Hub_GetBizflowModuleApprovalByDOCID = "[GSS1Hub_GetBizflowModuleApprovalByDOCID]";

        public const string GSS1Hub_GetHostDetailsDataBySearchText = "[GSS1Hub_GetHostDetailsDataBySearchText]";

        public const string GSS1Hub_GetCostCenterByTypeAndSearchText = "[GSS1Hub_GetCostCenterByTypeAndSearchText]";

        public const string GSS1Hub_GetTimeSheetStaticDataByProgramId = "[GSS1Hub_GetTimeSheetStaticDataByProgramId]";

        public const string GSS1Hub_ExcelUploaderConfigurationByKey = "[GSS1Hub_ExcelUploaderConfigurationByKey]";

        public const string GSS1Hub_InsertUploadedDataFormExcelUploader = "[GSS1Hub_InsertUploadedDataFormExcelUploader]";
        
        public const string GSS1Hub_GetSitesByUserEntity = "[GSS1Hub_GetSitesByUserEntity]";

        public const string GSS1Hub_GetDtrLOVData = "[GSS1Hub_GetDtrLOVData]";
        public const string GSS1Hub_GetDtrLOVDataByCode = "[GSS1Hub_GetDtrLOVDataByCode]";
        public const string GSS1Hub_InsertOrUpdateDtrListOfValues = "[GSS1Hub_InsertOrUpdateDtrListOfValues]";



        public const string GSS1Hub_GetExternalVanue = "[GSS1Hub_GetExternalVanue]";        
        public const string GSS1Hub_InsertOrUpdateExternalVanue = "[GSS1Hub_InsertOrUpdateExternalVanue]";
        public const string GSS1Hub_GetRooms = "[GSS1Hub_GetRooms]";
        public const string GSS1Hub_InsertOrUpdateRoom = "[GSS1Hub_InsertOrUpdateRoom]";


        public const string GSS1Hub_GetDTWorkTypeByProcess = "[GSS1Hub_GetDTWorkTypeByProcess]";

        //public const string GSS1Hub_GetUserModuleForTile = "[GSS1Hub_GetUserModuleForTile]";

        public const string GSS1Hub_getValueFromSysconfig = "[GSS1Hub_getValueFromSysconfig]";
    }
}