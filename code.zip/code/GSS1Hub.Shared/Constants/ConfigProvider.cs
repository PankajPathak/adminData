﻿using System.Configuration;

namespace GSS1Hub.Shared.Constants
{
    public class ConfigProvider
    {
        public static string HireCraftURL { get { return ConfigurationManager.AppSettings["HireCraftURL"]; } }
        public static string EncriptionKey { get { return ConfigurationManager.AppSettings["EncriptionKey"]; } }
        public static string LDAP_PATH { get { return ConfigurationManager.AppSettings["LDAP_PATH"]; } }
        public static string FileRootPath { get { return ConfigurationManager.AppSettings["FileRootPath"]; } }
        public static string ErrorLogRootPath { get { return ConfigurationManager.AppSettings["ErrorLogRootPath"]; } }
        public static string DTR_New_ProcessId { get { return ConfigurationManager.AppSettings["DTR_New_ProcessId"]; } }
        public static string DTR_New_ProcessName { get { return ConfigurationManager.AppSettings["DTR_New_ProcessName"]; } }
        public static string DTR_Update_ProcessId { get { return ConfigurationManager.AppSettings["DTR_Update_ProcessId"]; } }
        public static string DTR_Update_ProcessName { get { return ConfigurationManager.AppSettings["DTR_Update_ProcessName"]; } }

        public static string Inv_New_IT_ProcessId { get { return ConfigurationManager.AppSettings["Inv_New_IT_ProcessId"]; } }
        public static string Inv_New_IT_ProcessName { get { return ConfigurationManager.AppSettings["Inv_New_IT_ProcessName"]; } }

        public static string Inv_New_Adjustment_ProcessId { get { return ConfigurationManager.AppSettings["Inv_New_Adjustment_ProcessId"]; } }
        public static string Inv_New_Adjustment_ProcessName { get { return ConfigurationManager.AppSettings["Inv_New_Adjustment_ProcessName"]; } }

        public static string Inv_New_OverTime_ProcessId { get { return ConfigurationManager.AppSettings["Inv_New_OverTime_ProcessId"]; } }
        public static string Inv_New_OverTime_ProcessName { get { return ConfigurationManager.AppSettings["Inv_New_OverTime_ProcessName"]; } }

        public static string Pmt_ProjectManagementFlow_ProcessId { get { return ConfigurationManager.AppSettings["Pmt_ProjectManagementFlow_ProcessId"]; } }
        public static string Pmt_ProjectManagementFlow_ProcessName { get { return ConfigurationManager.AppSettings["Pmt_ProjectManagementFlow_ProcessName"]; } }

        public static string Inv_New_TimeSheet_ProcessId { get { return ConfigurationManager.AppSettings["Inv_New_TimeSheet_ProcessId"]; } }
        public static string Inv_New_TimeSheet_ProcessName { get { return ConfigurationManager.AppSettings["Inv_New_TimeSheet_ProcessName"]; } }

        public static string Gss1Hub_CubConnection { get { return ConfigurationManager.ConnectionStrings["SSAS_Context"].ConnectionString; } }

        public static string EmpMovement_New_ProcessId { get { return ConfigurationManager.AppSettings["EmpMovement_New_ProcessId"]; } }
        public static string EmpMovement_New_ProcessName { get { return ConfigurationManager.AppSettings["EmpMovement_New_ProcessName"]; } }

        public static string Edge_UserEnrollment_ProcessId { get { return ConfigurationManager.AppSettings["Edge_UserEnrollment_ProcessId"]; } }
        public static string Edge_UserEnrollment_ProcessName { get { return ConfigurationManager.AppSettings["Edge_UserEnrollment_ProcessName"]; } }
        public static string Edge_Reimbursement_ProcessId { get { return ConfigurationManager.AppSettings["Edge_Reimbursement_ProcessId"]; } }
        public static string Edge_Reimbursement_ProcessName { get { return ConfigurationManager.AppSettings["Edge_Reimbursement_ProcessName"]; } }
    }
}