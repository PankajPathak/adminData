﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Security.Cryptography;
using System.IO;
using System.Text;
using GSS1Hub.Shared.Constants;

namespace GSS1Hub.Shared
{
    public static class EncryptionDecription
    {

        private static byte[] IV = { 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16 };
        // private static byte[] IV = { 0x01, 0x02 };

        //private byte[] EncriptionKey = Encoding.UTF8.GetBytes("r0b1nr0y"); // your solution key
        private static byte[] EncriptionKey = Encoding.UTF8.GetBytes(ConfigProvider.EncriptionKey); // your solution key

        public static string Encrypt(string prmInput)
        {
            byte[] InputByteArray = Encoding.UTF8.GetBytes(prmInput);

            DESCryptoServiceProvider des = new DESCryptoServiceProvider();
            MemoryStream ms = new MemoryStream();
            CryptoStream cs = new CryptoStream(ms, des.CreateEncryptor(EncriptionKey, IV), CryptoStreamMode.Write);

            cs.Write(InputByteArray, 0, InputByteArray.Length);

            cs.FlushFinalBlock();

            cs.Clear();
            cs = null;
            return Convert.ToBase64String(ms.ToArray());
        }

        public static string Decrypt(string prmInput)
        {
            byte[] inputByteArray;

            DESCryptoServiceProvider des = new DESCryptoServiceProvider();
            try
            {
                inputByteArray = Convert.FromBase64String(prmInput);
            }
            catch (Exception)
            {
                inputByteArray = null;
            }
            if (inputByteArray != null)
            {

                MemoryStream ms = new MemoryStream();
                CryptoStream cs = new CryptoStream(ms, des.CreateDecryptor(EncriptionKey, IV), CryptoStreamMode.Write);

                cs.Write(inputByteArray, 0, inputByteArray.Length);

                cs.FlushFinalBlock();

                cs.Clear();
                cs = null;

                return Encoding.UTF8.GetString(ms.ToArray());

            }
            else
            {
                return "";
            }
        }
    }
}
