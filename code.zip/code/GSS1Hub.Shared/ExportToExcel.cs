﻿using Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace GSS1Hub.Shared
{
    public static class ExportToExcel
    {

        private static string ConvertListToExcelString<T>(IEnumerable<T> data)
        {
            StringBuilder output = new StringBuilder();
            PropertyDescriptorCollection props = TypeDescriptor.GetProperties(typeof(T));
            foreach (PropertyDescriptor prop in props)
            {
                //output += prop.DisplayName; // header
                //output += "\t";

                output.Append(prop.DisplayName); // header
                output.Append("\t");
            }

            //output += "\r\n";
            output.Append("\r\n");
            foreach (T item in data)
            {
                foreach (PropertyDescriptor prop in props)
                {
                    //output += prop.Converter.ConvertToString(prop.GetValue(item));
                    //output += "\t";

                    output.Append(prop.Converter.ConvertToString(prop.GetValue(item)));
                    output.Append("\t");
                }
                //output += "\r\n";
                output.Append("\r\n");
            }
            return output.ToString();
        }

        private static string ConvertDataTableToExcelString(System.Data.DataTable dt)
        {
            StringBuilder output = new StringBuilder();
            foreach (DataColumn dc in dt.Columns)
            {
                output.Append(dc.ColumnName); // header
                output.Append("\t");

                //output += dc.ColumnName; // header
                //output += "\t";
            }

            //output += "\r\n";
            output.Append("\r\n");
            foreach (DataRow dr in dt.Rows)
            {
                for (int i = 0; i < dt.Columns.Count; i++)
                {
                    //output += dr[i].ToString();
                    //output += "\t";

                    output.Append(dr[i].ToString());
                    output.Append("\t");
                }
                //output += "\r\n";
                output.Append("\r\n");
            }
            return output.ToString();
        }

        public static HttpResponseMessage exportToExcel<T>(IEnumerable<T> data, string fileNameWithExtension)
        {
            HttpResponseMessage result = new HttpResponseMessage(HttpStatusCode.OK);
            result.Content = new StringContent(ConvertListToExcelString(data));
            /*
                var stream = new FileStream(@"C:\Source\Repos\GSS1Hub\GSS1Hub.Invoicing\Controllers\test.xls", FileMode.Open, FileAccess.Read);
                result.Content = new StreamContent(stream);
            */

            result.Content.Headers.ContentType = new MediaTypeHeaderValue("application/octet-stream");
            result.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment"); //attachment will force download
            result.Content.Headers.ContentDisposition.FileName = fileNameWithExtension;

            return result;
        }

        public static HttpResponseMessage exportToExcel(System.Data.DataTable data, string fileNameWithExtension)
        {
            HttpResponseMessage result = new HttpResponseMessage(HttpStatusCode.OK);
            result.Content = new StringContent(ConvertDataTableToExcelString(data));
            /*
                var stream = new FileStream(@"C:\Source\Repos\GSS1Hub\GSS1Hub.Invoicing\Controllers\test.xls", FileMode.Open, FileAccess.Read);
                result.Content = new StreamContent(stream);
            */

            result.Content.Headers.ContentType = new MediaTypeHeaderValue("application/octet-stream");
            result.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment"); //attachment will force download
            result.Content.Headers.ContentDisposition.FileName = fileNameWithExtension;
            result.StatusCode = data.Rows.Count > 0 ? HttpStatusCode.OK : HttpStatusCode.NoContent;
            return result;
        }

    }
}
