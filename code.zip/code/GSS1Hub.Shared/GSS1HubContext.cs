﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSS1Hub.Shared
{
    public class GSS1HubContext : DbContext
    {
        private DbContext _dbContext;
        public GSS1HubContext()
        {
            try
            {
                _dbContext = new DbContext("GSS1HubContext");
            }
            catch (Exception ex)
            {
                LogManager.WriteLog(LogManager.LogType.Error, ex.ToString());
                throw ex;
            }
        }

        public DbContext CurrentContext { get { return this._dbContext; } }

    }
}
