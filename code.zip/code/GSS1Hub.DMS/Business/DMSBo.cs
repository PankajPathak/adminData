﻿using GSS1Hub.DMS.Data;
using GSS1Hub.DMS.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSS1Hub.DMS.Business
{
    class DMSBo
    {
        private readonly IDMS _documentManagementData;
        public DMSBo()
        {
            this._documentManagementData = new DMSSql();
        }

        public long InsertDocumentDetails(DocumentDetails documentManagement)
        {
            return this._documentManagementData.InsertDocumentDetails(documentManagement);
        }

        public DocumentDetails GetAttachmentByGUID(string GUID)
        {
            return this._documentManagementData.GetAttachmentByGUID(GUID);

        }
    }
}
