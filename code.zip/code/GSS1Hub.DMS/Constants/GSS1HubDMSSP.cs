﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSS1Hub.DMS.Constants
{
    internal sealed class GSS1HubDMSSP
    {
        public const string INSERT_DOCUMENTDETAILS = "[GSS1Hub_DMS_InsertDocumentDetails]";
        public const string GET_ATTACHMENT_BY_GUID = "[GSS1Hub_DMS_GetAttachmentByGUID]";
    }
}
