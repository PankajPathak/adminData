﻿using GSS1Hub.DMS.Business;
using GSS1Hub.DMS.Models;
using GSS1Hub.Shared;
using GSS1Hub.Shared.Constants;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Http.Cors;

using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;


namespace GSS1Hub.DMS.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    public class DMSController : ApiController
    {

        private readonly DMSBo _documentManagementBo;
        public DMSController()
        {
            if (_documentManagementBo == null)
            {
                this._documentManagementBo = new DMSBo();
            }
        }

        [HttpPost]
        public DocumentDetails UploadAttachments(string ModuleName)
        {
            var fileSavePath = "";
            try
            {
                if (HttpContext.Current.Request.Files.AllKeys.Any())
                {
                    var httpPostedFile = HttpContext.Current.Request.Files["file"];
                    string GUID = Guid.NewGuid().ToString();
                    string Extension = Path.GetExtension(httpPostedFile.FileName);

                    string fileName = GUID + Extension;
                    string MIMETypes = MimeMapping.GetMimeMapping(fileName);


                    //#region Creating ModuleName Directory
                    bool ModuleNameFolderExits = Directory.Exists($"{ ConfigProvider.FileRootPath}/{ModuleName}");
                    if (!ModuleNameFolderExits)
                    {
                        Directory.CreateDirectory($"{ ConfigProvider.FileRootPath}/{ModuleName}");
                    }
                    //#endregion

                    //#region checking todayDate folder exists or not 

                    bool todayFolderExits = Directory.Exists($"{ ConfigProvider.FileRootPath}/{ModuleName}/{DateTime.Now.ToString("ddMMyyyyy")}");
                    if (!todayFolderExits)
                    {
                        Directory.CreateDirectory($"{ ConfigProvider.FileRootPath}/{ModuleName}/{DateTime.Now.ToString("ddMMyyyyy")}");
                    }

                    //#endregion

                    fileSavePath = Path.Combine($"{ ConfigProvider.FileRootPath}/{ModuleName}/{DateTime.Now.ToString("ddMMyyyyy")}", fileName);
                    httpPostedFile.SaveAs(fileSavePath);

                    DocumentDetails objDocumentManagement = new DocumentDetails();
                    objDocumentManagement.GUID = GUID;
                    objDocumentManagement.Extension = Extension;
                    objDocumentManagement.RelativePath = $"{ ModuleName}/{DateTime.Now.ToString("ddMMyyyyy")}/{fileName}";
                    objDocumentManagement.FileName = httpPostedFile.FileName;
                    objDocumentManagement.MIMETypes = MIMETypes;

                    _documentManagementBo.InsertDocumentDetails(objDocumentManagement);
                    //return $"{ "DMS"}/{fileName}";
                    return objDocumentManagement;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                string ErrorfilePath = ConfigProvider.ErrorLogRootPath;

                using (StreamWriter writer = new StreamWriter(ErrorfilePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString() + " FilePath :" + fileSavePath + "");
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
                return null;
            }
        }


        [HttpPost]
        public DocumentDetails ProfileImageSave(ProfileImageSave imgData)
        {
            var fileSavePath = "";
            try
            {
                //if (HttpContext.Current.Request.Files.AllKeys.Any())
                //{
                //var httpPostedFile = HttpContext.Current.Request.Files["file"];

                string base64String = imgData.ImageData;
                //----------------------------------------
                string fileExtensionApplication = ".jpeg";
                byte[] imageBytes = Convert.FromBase64String(base64String);
                MemoryStream ms = new MemoryStream(imageBytes, 0, imageBytes.Length);

                // Convert byte[] to Image
                ms.Write(imageBytes, 0, imageBytes.Length);
                System.Drawing.Image image = System.Drawing.Image.FromStream(ms, false);


                string GUID = Guid.NewGuid().ToString();
                string Extension = fileExtensionApplication;//Path.GetExtension(httpPostedFile.FileName);

                string fileName = GUID + Extension;
                string MIMETypes = MimeMapping.GetMimeMapping(fileName);


                //#region Creating ModuleName Directory
                bool ModuleNameFolderExits = Directory.Exists($"{ ConfigProvider.FileRootPath}/{imgData.ModuleName}");
                if (!ModuleNameFolderExits)
                {
                    Directory.CreateDirectory($"{ ConfigProvider.FileRootPath}/{imgData.ModuleName}");
                }
                //#endregion

                //#region checking todayDate folder exists or not 

                bool todayFolderExits = Directory.Exists($"{ ConfigProvider.FileRootPath}/{imgData.ModuleName}/{DateTime.Now.ToString("ddMMyyyyy")}");
                if (!todayFolderExits)
                {
                    Directory.CreateDirectory($"{ ConfigProvider.FileRootPath}/{imgData.ModuleName}/{DateTime.Now.ToString("ddMMyyyyy")}");
                }

                //#endregion

                fileSavePath = Path.Combine($"{ ConfigProvider.FileRootPath}/{imgData.ModuleName}/{DateTime.Now.ToString("ddMMyyyyy")}", fileName);
                //httpPostedFile.SaveAs(fileSavePath);
                image.Save(fileSavePath, ImageFormat.Jpeg);
                ms.Close();
                ms.Flush();


                DocumentDetails objDocumentManagement = new DocumentDetails();
                objDocumentManagement.GUID = GUID;
                objDocumentManagement.Extension = Extension;
                objDocumentManagement.RelativePath = $"{ imgData.ModuleName}/{DateTime.Now.ToString("ddMMyyyyy")}/{fileName}";
                objDocumentManagement.FileName = GUID;// httpPostedFile.FileName;
                objDocumentManagement.MIMETypes = MIMETypes;

                _documentManagementBo.InsertDocumentDetails(objDocumentManagement);
                //return $"{ "DMS"}/{fileName}";
                return objDocumentManagement;
                //}
                //else
                //{
                //    return null;
                //}
            }
            catch (Exception ex)
            {
                string ErrorfilePath = ConfigProvider.ErrorLogRootPath;

                using (StreamWriter writer = new StreamWriter(ErrorfilePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString() + " FilePath :" + fileSavePath + "");
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
                return null;
            }
        }





        [HttpGet]
        //[Route("getfile")]
        public HttpResponseMessage GetAttachment(string Id)
        {
            try
            {
                DocumentDetails documentDetails = new DocumentDetails();
                documentDetails = _documentManagementBo.GetAttachmentByGUID(Id);

                //var stream = File.ReadAllBytes(@"C:\GIT\GSS1Hub\GSS1Hub\DMS\20042017\Chrysanthemum.jpg");
                var stream = File.ReadAllBytes($"{ConfigProvider.FileRootPath}/" + documentDetails.RelativePath);
                // processing the stream.

                var result = new HttpResponseMessage(HttpStatusCode.OK)
                {
                    Content = new ByteArrayContent(stream)
                };

                result.Content.Headers.ContentDisposition = new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment")
                {
                    //FileName = "Chrysanthemum.jpg"
                    FileName = documentDetails.FileName
                };
                //result.Content.Headers.ContentType = new MediaTypeHeaderValue("image/jpeg");
                result.Content.Headers.ContentType = new MediaTypeHeaderValue(documentDetails.MIMETypes);

                return result;
            }
            catch (Exception ex)
            {
                LogManager.WriteLog(LogManager.LogType.Error, ex.ToString());
                var result = new HttpResponseMessage(HttpStatusCode.OK);
                result.Content = new ByteArrayContent(new byte[0]);
                return result;
            }
        }

        [HttpGet]

        public DocumentDetails GetAttachmentByGUID(string Id)
        {
            try
            {
                DocumentDetails documentDetails = new DocumentDetails();
                documentDetails = _documentManagementBo.GetAttachmentByGUID(Id);

                return documentDetails;

            }
            catch (Exception ex)
            {
                string ErrorfilePath = ConfigProvider.ErrorLogRootPath;

                using (StreamWriter writer = new StreamWriter(ErrorfilePath, true))
                {
                    writer.WriteLine("Message :" + ex.Message + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString() + " ");
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
                return null;
            }
        }

    }
}
