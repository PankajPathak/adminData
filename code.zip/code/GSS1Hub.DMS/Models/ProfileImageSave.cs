﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace GSS1Hub.DMS.Models
{
    [DataContract]
    public class ProfileImageSave
    {
        [DataMember]
        public string ImageData { get; set; }
        [DataMember]
        public string ModuleName { get; set; }
    }
}
