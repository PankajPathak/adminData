﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace GSS1Hub.DMS.Models
{
    [DataContract]
    public class DocumentDetails
    {
        [DataMember]
        public string GUID { get; set; }
        [DataMember]
        public string Extension { get; set; }
        [DataMember]
        public string RelativePath { get; set; }

        [DataMember]
        public string FileName { get; set; }

        [DataMember]
        public string MIMETypes { get; set; }
    }
}
