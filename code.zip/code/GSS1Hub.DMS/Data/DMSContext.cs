﻿using GSS1Hub.Shared;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSS1Hub.DMS.Data
{
    class DMSContext : DbContext
    {
        public DbContext _dbContext;
        public DMSContext()
        {
            try
            {
                _dbContext = new DbContext("GSS1HubContext");
            }
            catch (Exception ex)
            {
                LogManager.WriteLog(LogManager.LogType.Error, ex.ToString());
                throw ex;
            }
        }

    }
}
