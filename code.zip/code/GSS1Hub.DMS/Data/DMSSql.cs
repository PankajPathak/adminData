﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GSS1Hub.DMS.Models;
using GSS1Hub.DMS.Constants;
using System.Data.SqlClient;

namespace GSS1Hub.DMS.Data
{
    internal sealed class DMSSql : DMSContext, IDMS
    {
        public long InsertDocumentDetails(DocumentDetails documentManagement)
        {

            return this._dbContext.Database.ExecuteSqlCommand(GSS1HubDMSSP.INSERT_DOCUMENTDETAILS + "@GUID,@Extension, @RelativePath,@FileName, @MIMETypes",
                new SqlParameter("@GUID", documentManagement.GUID),
                new SqlParameter("@Extension", documentManagement.Extension),
                new SqlParameter("@RelativePath", documentManagement.RelativePath),
                new SqlParameter("@FileName", documentManagement.FileName),
                new SqlParameter("@MIMETypes", documentManagement.MIMETypes));
        }

        public DocumentDetails GetAttachmentByGUID(string GUID)
        {
            return this._dbContext.Database.SqlQuery<DocumentDetails>(GSS1HubDMSSP.GET_ATTACHMENT_BY_GUID + "@GUID",
                new SqlParameter("@GUID", GUID)).FirstOrDefault();
        }
    }
}
