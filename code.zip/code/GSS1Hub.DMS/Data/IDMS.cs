﻿using GSS1Hub.DMS.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSS1Hub.DMS.Data
{
    interface IDMS
    {
        long InsertDocumentDetails(DocumentDetails documentManagement);
        DocumentDetails GetAttachmentByGUID(string GUID);
    }
}
