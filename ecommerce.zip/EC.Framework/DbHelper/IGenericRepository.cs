﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EC.Framework.Utilities;

namespace EC.Framework.DbHelper
{
    public interface IGenericRepository<T>
    {
        IEnumerable<T> GetAll(Param param);
        T GetById(long id);
        T Create(T type);
        T Update(T type);
        T Delete(T type);
    }
}
