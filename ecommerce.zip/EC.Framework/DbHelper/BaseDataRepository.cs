﻿using EC.Framework.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.Entity;
using System.Linq;
using System.Text;

namespace EC.Framework.DbHelper
{
    public abstract class BaseDataRepository<T>
    {
        public DbContext _dbContext;
        public ILogger _iLogger;
        public BaseDataRepository()
        {
            try
            {
                _dbContext = new DbContext("DefaultDbConnection");
                _iLogger = new Logging.Logging();
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        
        //public abstract T DataToObject(DataRow dataRow);
    }
}
