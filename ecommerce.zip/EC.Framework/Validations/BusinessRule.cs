﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EC.Framework.Validations
{
    public abstract class BusinessRule<T>
    {
        public abstract void Validate(T type);
    }
}
