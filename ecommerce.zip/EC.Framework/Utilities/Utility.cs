﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace EC.Framework.Utilities
{
    public static class Utility
    {
        public static DateTime FirstDateOfWeek(int year, int month, int weekNum, CalendarWeekRule rule)
        {
            DateTime date = new DateTime(year, month, 1);

            int daysOffset = DayOfWeek.Monday - date.DayOfWeek;
            //int daysOffset = date.DayOfWeek - DayOfWeek.Monday;
            if (daysOffset == 1)
            {
                daysOffset = -6;
            }
            DateTime firstMonday = date.AddDays(daysOffset);

            //int daysOffset = (int)date.DayOfWeek;
            //DateTime firstMonday = date;

            var cal = CultureInfo.CurrentCulture.Calendar;
            int firstWeek = cal.GetWeekOfYear(firstMonday, rule, CultureInfo.CurrentCulture.DateTimeFormat.FirstDayOfWeek);
            //int firstWeek = cal.GetWeekOfYear(firstMonday, rule, date.DayOfWeek);

            if (firstWeek <= 1)
            {
                weekNum -= 1;
            }

            DateTime result = firstMonday.AddDays(weekNum * 7);

            return result;
        }

        public static string GetWeekDateRange(int month, int weekNo)
        {
            string firstDate = string.Empty;
            string lastDate = string.Empty;

            DateTime dTime = FirstDateOfWeek(DateTime.Now.Year, month, weekNo, CalendarWeekRule.FirstDay);
            for (DateTime d = dTime; d < dTime.AddDays(7); d = d.AddDays(1))
            {
                if (d.Month == month)
                {
                    if (firstDate.Trim() == string.Empty)
                    {
                        firstDate = d.ToString("dd MMM");
                    }

                    lastDate = d.ToString("dd MMM");
                }
            }
            return (firstDate + " - " + lastDate);
        }

        public static int GetWeekOfMonth(DateTime date)
        {
            DateTime beginningOfMonth = new DateTime(date.Year, date.Month, 1);

            while (date.Date.AddDays(1).DayOfWeek != CultureInfo.CurrentCulture.DateTimeFormat.FirstDayOfWeek)
                date = date.AddDays(1);

            return (int)Math.Truncate((double)date.Subtract(beginningOfMonth).TotalDays / 7f) + 1;
        }

        public static Dictionary<int, string> GetAllYears(int fromYear, int toYear)
        {
            Dictionary<int, string> years = new Dictionary<int, string>();
            for (int i = toYear; i >= fromYear; i--)
            {
                years.Add((i), i.ToString());
            }
            return years;
        }

        public static Dictionary<int, string> GetAllMonthNames()
        {
            Dictionary<int, string> monthNames = new Dictionary<int, string>();
            for (int i = 0; i < 12; i = i + 1)
            {
                System.Globalization.DateTimeFormatInfo mfi = new System.Globalization.DateTimeFormatInfo();
                string monthName = mfi.GetMonthName((i + 1)).Substring(0, 3);

                monthNames.Add((i + 1), monthName);
            }
            return monthNames;
        }

        public static Dictionary<int, string> GetWeeks(int year, int month, bool includeWeekend = false)
        {
            //int year = DateTime.Now.Year;
            //DateTime date = new DateTime(year, month, 1);
            ////DayOfWeek wkstart = DayOfWeek.Monday;
            //DayOfWeek wkstart = date.DayOfWeek;


            //DateTime first = new DateTime(year, month, 1);
            //int firstwkday = (int)first.DayOfWeek;
            //int otherwkday = (int)wkstart;

            //double weeks = (double)(DateTime.DaysInMonth(year, month)) / 7d;
            //int wkData = (int)Math.Ceiling(weeks);

            DateTime today = DateTime.Now;
            //extract the month
            int daysInMonth = DateTime.DaysInMonth(year, month);
            DateTime firstOfMonth = new DateTime(year, month, 1);
            //days of week starts by default as Sunday = 0
            int firstDayOfMonth = (int)firstOfMonth.DayOfWeek;
            switch (firstDayOfMonth)
            {
                case 0:
                    firstDayOfMonth = 7;
                    break;
                case 1:
                    firstDayOfMonth = 5;
                    break;
                case 2:
                    firstDayOfMonth = 4;
                    break;
                case 3:
                    firstDayOfMonth = 3;
                    break;
                case 4:
                    firstDayOfMonth = 2;
                    break;
                case 5:
                    firstDayOfMonth = 1;
                    break;
                //case 6:
                //    firstDayOfMonth = 0;
                //    break;
                default:
                    break;
            }
            //if (firstDayOfMonth == 0)
            //{
            //    firstDayOfMonth = 7;
            //}
            int weeksInMonth = (int)Math.Ceiling((firstDayOfMonth + daysInMonth) / 7.0);
            //if (firstDayOfMonth <= 5)
            //{
            //    weeksInMonth--;
            //}

            Dictionary<int, string> wkList = new Dictionary<int, string>();
            for (int i = 0; i < weeksInMonth; i++)
            {
                wkList.Add((i + 1), GetWeekDateRange(month, i));
            }

            return wkList;
        }

        public static string GetMonthName(int month, bool shortName = true)
        {
            System.Globalization.DateTimeFormatInfo mfi = new System.Globalization.DateTimeFormatInfo();
            string monthName = string.Empty;
            if (shortName)
            {
                monthName = mfi.GetMonthName(month).Substring(0, 3);
            }
            else
            {
                monthName = mfi.GetMonthName(month);
            }
            return monthName;
        }

        public static string GetWeekName(int weekNo)
        {
            string weekName = "Week " + weekNo;
            return weekName;
        }

        public static string GetSystemIPAddress()
        {
            if (!System.Net.NetworkInformation.NetworkInterface.GetIsNetworkAvailable())
            {
                return "NULL";
            }

            var host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (var ip in host.AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                {
                    return ip.ToString();
                }
            }
            throw new Exception("Local IP Address Not Found!");
        }

        public static bool IsValidEmail(string email)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return (addr.Address == email);
            }
            catch
            {
                return false;
            }
        }
    }
}
