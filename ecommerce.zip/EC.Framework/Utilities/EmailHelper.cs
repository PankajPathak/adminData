﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Net.Mime;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace EC.Framework.Utilities
{
    public class EmailHelper
    {
        public string ToEmail { get; set; }
        public string FromEmail { get; set; }
        public string Bcc { get; set; }
        public string CC { get; set; }
        public string Subject { get; set; }
        public string Body { get; set; }
        public List<string> attachmentFullPath { get; set; }

        public async Task SendEmail()
        {
            var message = new MailMessage();

            using (var smtpClient = new SmtpClient())
            {
                await smtpClient.SendMailAsync(message);
            }
        }

        /// <summary>
        /// This helper class sends an email message using the System.Net.Mail namespace
        /// </summary>
        /// <param name="fromEmail">Sender email address</param>
        /// <param name="toEmail">Recipient email address</param>
        /// <param name="bcc">Blind carbon copy email address</param>
        /// <param name="cc">Carbon copy email address</param>
        /// <param name="subject">Subject of the email message</param>
        /// <param name="body">Body of the email message</param>
        /// <param name="attachment">File to attach</param>

        #region Static Members

        public async Task SendMailMessage()
        {
            System.Net.NetworkCredential credentials = new System.Net.NetworkCredential("username", "password");
            //create the MailMessage object
            MailMessage mMailMessage = new MailMessage();

            //set the sender address of the mail message
            if (!string.IsNullOrEmpty(this.FromEmail))
            {
                mMailMessage.From = new MailAddress(this.FromEmail);
            }

            //set the recipient address of the mail message
            mMailMessage.To.Add(new MailAddress(this.ToEmail));

            //set the blind carbon copy address
            if (!string.IsNullOrEmpty(this.Bcc))
            {
                mMailMessage.Bcc.Add(new MailAddress(this.Bcc));
            }

            //set the carbon copy address
            if (!string.IsNullOrEmpty(this.CC))
            {
                mMailMessage.CC.Add(new MailAddress(this.CC));
            }

            //set the subject of the mail message
            if (!string.IsNullOrEmpty(this.Subject))
            {
                mMailMessage.Subject = Subject;
            }
            else
            {
                mMailMessage.Subject = "Mail Notifications";

            }

            //set the body of the mail message
            mMailMessage.Body = Body;

            //set the format of the mail message body
            mMailMessage.IsBodyHtml = true;

            //set the priority
            mMailMessage.Priority = MailPriority.Normal;
            if (attachmentFullPath != null)
            {
                //add any attachments from the filesystem
                foreach (var attachmentPath in attachmentFullPath)
                {
                    Attachment mailAttachment = new Attachment(attachmentPath);
                    mMailMessage.Attachments.Add(mailAttachment);
                }
            }
            //create the SmtpClient instance
            using (SmtpClient SmtpClient = new SmtpClient())
            {

                SmtpClient.Host = "smtp.starclinch.com";
                SmtpClient.Port = 25;

                //SmtpClient.Port = 80;
                SmtpClient.UseDefaultCredentials = false;
                SmtpClient.Credentials = credentials;
                SmtpClient.EnableSsl = false;

                try
                {
                    SmtpClient.Send(mMailMessage);
                }
                catch (Exception ex)
                {
                }
            }
        }

        /// <summary>
        /// Determines whether an email address is valid.
        /// </summary>
        /// <param name="emailAddress">The email address to validate.</param>
        /// <returns>
        /// 	<c>true</c> if the email address is valid; otherwise, <c>false</c>.
        /// </returns>
        public static bool IsValidEmailAddress(string emailAddress)
        {
            // An empty or null string is not valid
            if (String.IsNullOrEmpty(emailAddress))
            {
                return (false);
            }

            // Regular expression to match valid email address
            string emailRegex = @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}" +
                                @"\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\" +
                                @".)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$";

            // Match the email address using a regular expression
            Regex re = new Regex(emailRegex);
            if (re.IsMatch(emailAddress))
                return (true);
            else
                return (false);
        }

        #endregion

        /// <summary>
        /// to convert static images to embedded images
        /// for the purpose of auto download images
        /// 
        /// </summary>
        /// <param name="File"></param>
        /// <param name="email"></param>
        /// <returns></returns>

        public List<AlternateView> getEmbeddeImage(IEnumerable<string> File, string email)
        {
            List<AlternateView> listAlternateView = new List<AlternateView>();
            foreach (var item in File)
            {
                LinkedResource linkedResource = new LinkedResource(item);
                linkedResource.ContentId = Guid.NewGuid().ToString();
                string htmlBody = string.Format(email, linkedResource.ContentId);

                AlternateView alternateView = AlternateView.CreateAlternateViewFromString(htmlBody, null, MediaTypeNames.Text.Html);
                alternateView.LinkedResources.Add(linkedResource);
                listAlternateView.Add(alternateView);
            }
            return listAlternateView;
        }

    }
}
