﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EC.Framework.Utilities
{
    public class Param
    {
        public long Id { get; set; }

        public int PageNo { get; set; }
        public int PageSize { get; set; }
        public int TotalRecords { get; set; }

        public string OrderBy { get; set; }
        public string ColName { get; set; }

        public bool RefPage { get; set; }
        public bool IsNavigation { get; set; }

        public long UserId { get; set; }

        public long ProfileStatusId { get; set; }
        public long StatusId { get; set; }
        public long RecordStatusId { get; set; }

        public ICollection<string> Searches { get; set; }
    }

    public class Search
    {
        public string Name { get; set; }
        public string Value { get; set; }
    }
}
