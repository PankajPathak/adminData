﻿using System;

namespace EC.Framework.Logging
{
    public interface ILogger
    {
    }
}
