﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace EC.Framework.Logging
{
    public static class LoggerExtensions
    {
        public static void Critical(this ILogger logger, string message)
        {
            FilteredLog(logger, TraceEventType.Critical, null, message, null);
        }
        public static void Error(this ILogger logger, string message)
        {
            FilteredLog(logger, TraceEventType.Error, null, message, null);
        }
        public static void Information(this ILogger logger, string message)
        {
            FilteredLog(logger, TraceEventType.Information, null, message, null);
        }
        public static void Resume(this ILogger logger, string message)
        {
            FilteredLog(logger, TraceEventType.Resume, null, message, null);
        }
        public static void Start(this ILogger logger, string message)
        {
            FilteredLog(logger, TraceEventType.Start, null, message, null);
        }
        public static void Stop(this ILogger logger, string message)
        {
            FilteredLog(logger, TraceEventType.Stop, null, message, null);
        }
        public static void Suspend(this ILogger logger, string message)
        {
            FilteredLog(logger, TraceEventType.Suspend, null, message, null);
        }
        public static void Transfer(this ILogger logger, string message)
        {
            FilteredLog(logger, TraceEventType.Transfer, null, message, null);
        }
        public static void Verbose(this ILogger logger, string message)
        {
            FilteredLog(logger, TraceEventType.Verbose, null, message, null);
        }
        public static void Warning(this ILogger logger, string message)
        {
            FilteredLog(logger, TraceEventType.Warning, null, message, null);
        }

        public static void Critical(this ILogger logger, Exception exception, string message)
        {
            FilteredLog(logger, TraceEventType.Critical, exception, message, null);
        }
        public static void Error(this ILogger logger, Exception exception, string message)
        {
            FilteredLog(logger, TraceEventType.Error, exception, message, null);
        }
        public static void Information(this ILogger logger, Exception exception, string message)
        {
            FilteredLog(logger, TraceEventType.Information, exception, message, null);
        }
        public static void Resume(this ILogger logger, Exception exception, string message)
        {
            FilteredLog(logger, TraceEventType.Resume, exception, message, null);
        }
        public static void Start(this ILogger logger, Exception exception, string message)
        {
            FilteredLog(logger, TraceEventType.Start, exception, message, null);
        }
        public static void Stop(this ILogger logger, Exception exception, string message)
        {
            FilteredLog(logger, TraceEventType.Stop, exception, message, null);
        }
        public static void Suspend(this ILogger logger, Exception exception, string message)
        {
            FilteredLog(logger, TraceEventType.Suspend, exception, message, null);
        }
        public static void Transfer(this ILogger logger, Exception exception, string message)
        {
            FilteredLog(logger, TraceEventType.Transfer, exception, message, null);
        }
        public static void Verbose(this ILogger logger, Exception exception, string message)
        {
            FilteredLog(logger, TraceEventType.Verbose, exception, message, null);
        }
        public static void Warning(this ILogger logger, Exception exception, string message)
        {
            FilteredLog(logger, TraceEventType.Warning, exception, message, null);
        }

        public static void Critical(this ILogger logger, Exception exception, string message, Dictionary<string, object> extendedProperties)
        {
            FilteredLog(logger, TraceEventType.Critical, exception, message, extendedProperties);
        }
        public static void Error(this ILogger logger, Exception exception, string message, Dictionary<string, object> extendedProperties)
        {
            FilteredLog(logger, TraceEventType.Error, exception, message, extendedProperties);
        }
        public static void Information(this ILogger logger, Exception exception, string message, Dictionary<string, object> extendedProperties)
        {
            FilteredLog(logger, TraceEventType.Information, exception, message, extendedProperties);
        }
        public static void Resume(this ILogger logger, Exception exception, string message, Dictionary<string, object> extendedProperties)
        {
            FilteredLog(logger, TraceEventType.Resume, exception, message, extendedProperties);
        }
        public static void Start(this ILogger logger, Exception exception, string message, Dictionary<string, object> extendedProperties)
        {
            FilteredLog(logger, TraceEventType.Start, exception, message, extendedProperties);
        }
        public static void Stop(this ILogger logger, Exception exception, string message, Dictionary<string, object> extendedProperties)
        {
            FilteredLog(logger, TraceEventType.Stop, exception, message, extendedProperties);
        }
        public static void Suspend(this ILogger logger, Exception exception, string message, Dictionary<string, object> extendedProperties)
        {
            FilteredLog(logger, TraceEventType.Suspend, exception, message, extendedProperties);
        }
        public static void Transfer(this ILogger logger, Exception exception, string message, Dictionary<string, object> extendedProperties)
        {
            FilteredLog(logger, TraceEventType.Transfer, exception, message, extendedProperties);
        }
        public static void Verbose(this ILogger logger, Exception exception, string message, Dictionary<string, object> extendedProperties)
        {
            FilteredLog(logger, TraceEventType.Verbose, exception, message, extendedProperties);
        }
        public static void Warning(this ILogger logger, Exception exception, string message, Dictionary<string, object> extendedProperties)
        {
            FilteredLog(logger, TraceEventType.Warning, exception, message, extendedProperties);
        }

        private static void FilteredLog(ILogger logger, TraceEventType traceEventType, Exception exception,
            string message, Dictionary<string, object> extendedProperties)
        {
            //if (Logger.IsLoggingEnabled())
            //{
            //    try
            //    {
            //        LogEntry logEntry = new LogEntry();
            //        logEntry.Message = message;
            //        Logger.Write(logEntry, "DiskFiles", 5, 9000, traceEventType, traceEventType.ToString());
            //    }
            //    catch (Exception ex)
            //    {
            //        Logger.Write(ex.Message, "DiskFiles", 9, 9001, traceEventType, traceEventType.ToString());
            //    }
            //}
        }
    }
}
