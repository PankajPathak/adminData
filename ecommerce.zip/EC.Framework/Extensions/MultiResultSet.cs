﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Text;

namespace EC.Framework.Extensions
{
    public static class MultiResultSet
    {
        public static MultipleResultSetWrapper MultipleResults(this DbContext db, string storedProcedureName, object Parameter)
        {
            return new MultipleResultSetWrapper(db, storedProcedureName, Parameter);
        }

        public class MultipleResultSetWrapper
        {
            private readonly DbContext _db;
            private readonly object _Parameter;
            private readonly string _storedProcedure;
            public List<Func<IObjectContextAdapter, DbDataReader, IEnumerable>> _resultSets;

            public MultipleResultSetWrapper(DbContext db, string storedProcedureName, object Parameter)
            {
                _db = db;
                _Parameter = Parameter;
                _storedProcedure = storedProcedureName;
                _resultSets = new List<Func<IObjectContextAdapter, DbDataReader, IEnumerable>>();
            }

            public MultipleResultSetWrapper With<TResult>()
            {
                _resultSets.Add((adapter, reader) => adapter
                    .ObjectContext
                    .Translate<TResult>(reader)
                    .ToList());

                return this;
            }

            public List<IEnumerable> Execute()
            {
                var results = new List<IEnumerable>();
                var connection = _db.Database.Connection;
                connection.Open();
                try
                {
                    var command = connection.CreateCommand();
                    StringBuilder commandBuilder = new StringBuilder();//
                    command.CommandText = _storedProcedure;
                    Type myType = _Parameter.GetType();
                    IList<PropertyInfo> props = new List<PropertyInfo>(myType.GetProperties());
                    foreach (PropertyInfo prop in props)
                    {
                        object propValue = prop.GetValue(_Parameter, null);
                        DbParameter param = command.CreateParameter();
                        param.ParameterName = "@" + prop.Name;
                        param.Value = propValue;
                        command.Parameters.Add(param);
                        //commandBuilder.AppendFormat($"{param.ParameterName} ");
                        //Do something with propValue
                    }

                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    using (var reader = command.ExecuteReader())
                    {
                        var adapter = ((IObjectContextAdapter)_db);
                        foreach (var resultSet in _resultSets)
                        {
                            results.Add(resultSet(adapter, reader));
                            reader.NextResult();
                        }
                    }
                    return results;
                }
                finally
                {
                    connection.Close();
                    SqlConnection.ClearPool((SqlConnection)connection);
                }
            }
        }
    }
}
