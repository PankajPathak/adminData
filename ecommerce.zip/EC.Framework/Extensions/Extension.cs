﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

namespace EC.Framework.Extensions
{
    public static class Extension
    {
        /// <summary>
        /// Return True if Collection is Null of Empty otherwise False
        /// </summary>
        /// <param name="collection"></param>
        /// <returns></returns>
        public static bool IsNullOrEmpty(this ICollection collection)
        {
            return (collection == null || collection.Count == 0);
        }

        /// <summary>
        /// Return True if DataSet is Null of Empty otherwise False
        /// </summary>
        /// <param name="dataSet"></param>
        /// <returns></returns>
        public static bool IsNullOrEmpty(this DataSet dataSet)
        {
            return (dataSet == null && dataSet.Tables == null && dataSet.Tables.Count == 0);
        }
        

        /// <summary>
        /// Return True if DataTable is Null of Empty otherwise False
        /// </summary>
        /// <param name="dataTable"></param>
        /// <returns></returns>
        public static bool NotNullOrEmpty(this DataTable dataTable)
        {
            return (dataTable != null && dataTable.Rows.Count > 0);
        }

        /// <summary>
        /// Return XML Document after convert the given type in XML
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="t"></param>
        /// <returns></returns>
        public static XmlDocument ConvertToXml<T>(T t)
        {
            XmlDocument xmlDoc = new XmlDocument();
            XmlSerializer xmlSerializer = new XmlSerializer(t.GetType());
            using (MemoryStream xmlStream = new MemoryStream())
            {
                xmlSerializer.Serialize(xmlStream, t);
                xmlStream.Position = 0;
                xmlDoc.Load(xmlStream);
            }
            return xmlDoc;
        }

        /// <summary>
        /// Return Encrypted string with SHA256 algorithm
        /// </summary>
        /// <param name="password"></param>
        /// <returns></returns>
        public static string GetSHA256(this string text)
        {
            string hash = String.Empty;
            if (text == null || text == string.Empty)
            {
                return hash;
            }

            SHA256Managed crypt = new SHA256Managed();
            byte[] crypto = crypt.ComputeHash(Encoding.ASCII.GetBytes(text), 0, Encoding.ASCII.GetByteCount(text));
            foreach (byte bit in crypto)
            {
                hash += bit.ToString("x2");
            }
            return hash;
        }

        /// <summary>
        /// Return Encrypted string with SHA256 algorithm with Unicode otpions
        /// </summary>
        /// <param name="text"></param>
        /// <returns></returns>
        public static string GetHashSHA256(this string text)
        {
            byte[] bytes = Encoding.Unicode.GetBytes(text);
            SHA256Managed hashstring = new SHA256Managed();
            byte[] hash = hashstring.ComputeHash(bytes);
            string hashString = string.Empty;
            foreach (byte x in hash)
            {
                hashString += String.Format("{0:x2}", x);
            }
            return hashString;
        }

        public static DateTime FirstDayOfWeek(this DateTime date)
        {
            DayOfWeek fdow = CultureInfo.CurrentCulture.DateTimeFormat.FirstDayOfWeek;
            int offset = fdow - date.DayOfWeek;
            DateTime fdowDate = date.AddDays(offset);
            return fdowDate;
        }

        public static DateTime LastDayOfWeek(this DateTime date)
        {
            DateTime ldowDate = FirstDayOfWeek(date).AddDays(6);
            return ldowDate;
        }
    }
}
