﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EC.Framework.DbHelper;
using EC.Models.Types;

namespace SC.Business.Interfaces
{
    public interface ICommonBusiness
    {
        IEnumerable<Country> GetAllCountries();
        IEnumerable<State> GetAllStatesByCountryId(long id);
        IEnumerable<City> GetAllCitiesByStateId(long id);
    }
}
