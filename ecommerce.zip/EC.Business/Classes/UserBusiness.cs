﻿using EC.Data.Classes;
using EC.Data.Interfaces;
using EC.Framework.Validations;
using EC.Models.Types;
using SC.Business.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EC.Business.Classes
{
    public sealed class UserBusiness : BusinessRule<User>, IUserBusiness
    {
        private static IUserData _iUserData;
        public UserBusiness()
        {
            _iUserData = new UserData();
        }

        public override void Validate(User user)
        {
            user.IsValid = true;
            if (string.IsNullOrWhiteSpace(user.Email))
            {
                user.IsValid = false;
                user.Message = "Invalid User";
            }
            if (string.IsNullOrWhiteSpace(user.Password))
            {
                user.IsValid = false;
                user.Message = "Invalid Password";
            }
        }

        public User AuthenticateUser(User user)
        {
            this.Validate(user);
            if (user.IsValid)
            {
                user = _iUserData.AuthenticateUser(user);
            }
            return user;
        }
    }
}
