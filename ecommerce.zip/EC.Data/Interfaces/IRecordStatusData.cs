﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EC.Framework.DbHelper;
using EC.Models.Types;

namespace EC.Data.Interfaces
{
    public interface IRecordStatusData : IGenericRepository<RecordStatus>
    {
    }
}
