﻿using EC.Framework.DbHelper;
using EC.Models.Types;
using EC.Data.Interfaces;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EC.Framework.Extensions;
using EC.Framework.Logging;

namespace EC.Data.Classes
{
    public sealed class UserData : BaseDataRepository<User>, IUserData
    {
        public User AuthenticateUser(User user)
        {
            User userObject = new User();
            try
            {
                var result = _dbContext
                           .MultipleResults("USP_AuthenticateUser", user)
                           .With<User>()
                           .Execute();
                userObject = (((IEnumerable<User>)result[0]).FirstOrDefault() == null) ? new User() : ((IEnumerable<User>)result[0]).FirstOrDefault() as User;
            }
            catch (Exception ex)
            {
                _iLogger.Error(ex.Message);
                //throw ex;
            }
            return userObject;
        }
    }
}
