﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EC.Framework.DbHelper;
using EC.Models.Types;
using System.ServiceModel;
using System.ServiceModel.Web;

namespace SC.Services.Interfaces
{
    [ServiceContract]
    public interface IUserService
    {
        [OperationContract]
        User AuthenticateUser(User user);

        [OperationContract]
        [WebInvoke(Method = "GET", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        string GetName(string name);
    }
}
