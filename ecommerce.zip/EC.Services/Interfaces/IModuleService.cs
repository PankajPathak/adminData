﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EC.Framework.DbHelper;
using EC.Models.Types;

namespace SC.Services.Interfaces
{
    public interface IModuleService : IGenericRepository<Module>
    {
        IEnumerable<Module> GetAllModulesByRoleId(long id);
    }
}
