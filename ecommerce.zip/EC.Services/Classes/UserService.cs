﻿using EC.Business.Classes;
using SC.Business.Interfaces;
using SC.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EC.Models.Types;

namespace EC.Services.Classes
{
    public class UserService : IUserService
    {
        private static IUserBusiness _iUserBusiness;
        public UserService()
        {
            _iUserBusiness = new UserBusiness();
        }

        public User AuthenticateUser(User user)
        {
            return _iUserBusiness.AuthenticateUser(user);
        }

        public string GetName(string name)
        {
            return "Welcome " + name.ToUpper();
        }
    }
}
