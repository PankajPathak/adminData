﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EC.Models.Types
{
    /// <summary>
    /// Base Entity Class: Common properties which will be attached with records
    /// </summary>
    public class BaseEntity
    {
        public long Id { get; set; }

        public string Code { get; set; }

        public string Name { get; set; }

        public long CreatedBy { get; set; }

        public string CreatedOn { get; set; }

        public long UpdatedBy { get; set; }

        public string UpdatedOn { get; set; }

        public RecordStatus RecordStatus { get; set; }

        /*Tracking records status while doing any operations like add/update/delete and set message according to the needs*/
        public bool IsSuccess { get; set; }

        public bool IsValid { get; set; }

        public string Message { get; set; }

        public RecordMode RecordMode { get; set; }

        public string CustomDateFormat
        {
            get
            {
                return "dd-MMM-yyyy";
            }
        }
    }

    public enum RecordMode
    {
        None,
        Create,
        Update,
        Delete,
        Activate,
        DeActivate,
        View
    }
}
