﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EC.Models.Types
{
    /// <summary>
    /// Permission Class: all permission properties
    /// </summary>
    public class Permission : BaseEntity
    {
        public long ModuleId { get; set; }
        public string ModuleName { get; set; }
        public long SubModuleId { get; set; }
        public string SubModuleName { get; set; }
        public string Description { get; set; }
        public bool Checked { get; set; }
    }
}
