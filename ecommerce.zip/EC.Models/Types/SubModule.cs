﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EC.Models.Types
{
    public class SubModule : BaseEntity
    {
        public SubModule()
        {
            Permissions = new HashSet<Permission>();
        }

        public long ModuleId { get; set; }

        public string ModuleName { get; set; }

        public string Description { get; set; }

        public long Sequence { get; set; }

        public string DefaultController { get; set; }

        public string DefaultAction { get; set; }

        public string CssIconName { get; set; }

        public ICollection<Permission> Permissions { get; set; }
    }
}
