﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EC.Models.Types
{
    public class Holiday : BaseEntity
    {
        public string Description { get; set; }

        private string _date { get; set; }
        public string Date
        {
            get { return _date; }
            set
            {
                if (value != null && value.Trim() != string.Empty)
                {
                    try
                    {
                        _date = Convert.ToDateTime(value).ToString(CustomDateFormat);
                    }
                    catch
                    {
                        _date = value;
                    }
                }
            }
        }
    }
}
