﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EC.Models.Types
{
    public class Address
    {
        public long Id { get; set; }
        
        public AddressType AddressType { get; set; }

        public string AddressLine1 { get; set; }

        public string AddressLine2 { get; set; }

        public string Landmark { get; set; }

        public City City { get; set; }

        public State State { get; set; }

        public Country Country { get; set; }

        public string Zip { get; set; }

        //public string FullAddress
        //{
        //    get
        //    {
        //        return
        //            (((string.IsNullOrWhiteSpace(AddressLine1)) ? string.Empty : AddressLine1 + ", ") +
        //            ((string.IsNullOrWhiteSpace(AddressLine2)) ? string.Empty : AddressLine2 + ", ") +
        //            ((string.IsNullOrWhiteSpace(Landmark)) ? string.Empty : Landmark + ", ") +
        //            (((City == null && City.Name == null)) ? string.Empty : City.Name + ", ") +
        //            (((State == null && State.Name == null)) ? string.Empty : State.Name + ", ") +
        //            (((Country == null && Country.Name == null)) ? string.Empty : Country.Name + ", ") +
        //            ((string.IsNullOrWhiteSpace(Zip)) ? string.Empty : Zip + ", "));
        //    }
        //}
    }
}
