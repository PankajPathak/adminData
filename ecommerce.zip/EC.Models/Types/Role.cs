﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EC.Models.Types
{
    /// <summary>
    /// Role Class: Role properties
    /// </summary>
    public class Role : BaseEntity
    {
        public string Description { get; set; }
    }
}
