﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EC.Models.Types
{
    /// <summary>
    /// Status Class: hold the status for each records i.e. Active, Inactive, Hold, Deleted etc
    /// </summary>
    public class RecordStatus
    {
        public long Id { get; set; }

        public string Code { get; set; }

        public string Name { get; set; }

        public string Type { get; set; }

        public long CreatedBy { get; set; }

        public string CreatedOn { get; set; }

        public long UpdatedBy { get; set; }

        public string UpdatedOn { get; set; }
    }
}
