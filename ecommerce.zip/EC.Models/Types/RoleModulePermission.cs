﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EC.Models.Types
{
    public class RoleModulePermission : BaseEntity
    {
        public string Description { get; set; }

        public Role Role { get; set; }

        public ICollection<Module> Modules { get; set; }
    }
}
