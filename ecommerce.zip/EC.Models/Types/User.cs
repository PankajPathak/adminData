﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EC.Framework.Security;

namespace EC.Models.Types
{
    public class User : BaseEntity
    {
        public string Email { get; set; }

        public string UserName { get; set; }

        private string _password;
        public string Password
        {
            get
            {
                return _password;
            }
            set
            {
                //_password = Hashing.CalculateMD5Hash(value);
                _password = value;
            }
        }

        public bool RememberMe { get; set; }
        
        public bool IsSysAdmin { get; set; }
    }
}
