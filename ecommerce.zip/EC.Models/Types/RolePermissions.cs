﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EC.Models.Types
{
    public class RolePermissions : BaseEntity
    {
        public long RoleId { get; set; }
        public long ModuleId { get; set; }
        public long SubModuleId { get; set; }
        public long PermissionId { get; set; }
    }
}
