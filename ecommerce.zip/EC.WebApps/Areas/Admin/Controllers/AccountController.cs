﻿using EC.Framework.Utilities;
using EC.Models.Types;
using EC.Services.Classes;
using EC.WebApps.Filters;
using SC.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace EC.WebApps.Areas.Admin.Controllers
{
    [Authorize]
    public class AccountController : Controller
    {
        private readonly IUserService _iUserService;
        public AccountController()
        {
            _iUserService = _iUserService ?? new UserService();
        }

        [AllowAnonymous]
        public ActionResult Login()
        {
            return View();
        }

        [AllowAnonymous, HttpPost, ValidateAntiForgeryToken]
        public ActionResult Login(User user)
        {
            User userObj = _iUserService.AuthenticateUser(user);
            if (userObj != null && userObj.IsSuccess)
            {
                FormsAuthentication.SetAuthCookie(userObj.Email, true);
                Session["UserSession"] = userObj;
                return RedirectToLocal(string.Empty);
            }
            return View(user);
        }

        [AllowAnonymous, HttpPost, ValidateAntiForgeryToken]
        public ActionResult ForgetPassword(User user)
        {
            if (!string.IsNullOrWhiteSpace(user.Email))
            {
            }
            return View("Login");
            //if (string.IsNullOrWhiteSpace(user.Email))
            //{
            //    ModelState.AddModelError("", "The email is required.");
            //    return Json(new
            //    {
            //        Status = false,
            //        Message = "The email is required. Please try again."
            //    }, JsonRequestBehavior.AllowGet);
            //}

            //if (Utility.IsValidEmail(user.Email))
            //{
            //    return Json(new
            //    {
            //        Status = true,
            //        Message = "Password link has been sent to your mail."
            //    }, JsonRequestBehavior.AllowGet);
            //}

            //return Json(new
            //{
            //    Status = false,
            //    Message = "Invalid email."
            //}, JsonRequestBehavior.AllowGet);
        }

        [NoCache]
        public ActionResult LogOff()
        {
            Session["UserSession"] = null;
            Session.Clear();
            Session.Abandon();
            Session.RemoveAll();

            FormsAuthentication.SignOut();

            FormsAuthentication.RedirectToLoginPage();
            Response.Redirect("/Admin/Account/Login");
            return RedirectToAction("Login");
        }

        private ActionResult RedirectToLocal(string returnUrl)
        {
            if (Url.IsLocalUrl(returnUrl))
            {
                return Redirect(returnUrl);
            }
            else
            {
                return RedirectToAction("Index", "Dashboard");
            }
        }
    }
}