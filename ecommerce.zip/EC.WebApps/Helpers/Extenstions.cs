﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;
using EC.Models.Types;

namespace EC.WebApps.Helpers
{
    public static class Extensions
    {
        public static bool HasRequiredPermission(this Controller controller, User user)
        {
            return false;
        }

        public static bool IsOk(this User user)
        {
            return true;
        }
    }
}
