﻿using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using SC.Models.Enums;
using SC.Models.Types;
using EC.WebApps.Storage;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace EC.WebApps.Helpers
{
    public class ImageService
    {
        private static string fileExtensionApplication = ".jpg";

        private async Task<string> UploadImageAsync(HttpPostedFileBase imageToUpload)
        {
            string imageFullPath = null;
            if (imageToUpload == null || imageToUpload.ContentLength == 0)
            {
                return null;
            }
            try
            {
                CloudStorageAccount cloudStorageAccount = BlobStorageConnection.GetConnectionString();
                CloudBlobClient cloudBlobClient = cloudStorageAccount.CreateCloudBlobClient();
                //CloudBlobContainer cloudBlobContainer = cloudBlobClient.GetContainerReference("img/unapprovedimages");
                CloudBlobContainer cloudBlobContainer = cloudBlobClient.GetContainerReference(BlobStorageConnection.GetImgRootContainerReference());

                if (await cloudBlobContainer.CreateIfNotExistsAsync())
                {
                    await cloudBlobContainer.SetPermissionsAsync(
                        new BlobContainerPermissions
                        {
                            PublicAccess = BlobContainerPublicAccessType.Blob
                        }
                        );
                }

                string imageName = Guid.NewGuid().ToString() + Path.GetExtension(imageToUpload.FileName);

                CloudBlockBlob cloudBlockBlob = cloudBlobContainer.GetBlockBlobReference(
                                                    BlobStorageConnection.GetUnApprovedImagesRootContainerReference() + "/" + imageName);
                cloudBlockBlob.Properties.ContentType = imageToUpload.ContentType;
                await cloudBlockBlob.UploadFromStreamAsync(imageToUpload.InputStream);

                imageFullPath = cloudBlockBlob.Uri.ToString();
            }
            catch (Exception ex)
            {
            }
            return imageFullPath;
        }

        public async Task<List<ReturnUrl>> SaveImage(ImageInfo imgData)
        {
            List<ReturnUrl> objReturnUrl = new List<ReturnUrl>();
            string imageFullPath = null;
            try
            {
                Image image = Base64ToImage(imgData.ImageData);

                if (imgData.Type == PictureType.CoverPicture)
                {
                    Size objSize = new Size(1366, 400);
                    image = ResizeImage(image, objSize);
                }
                string imageName = Guid.NewGuid().ToString() + fileExtensionApplication;
                byte[] imageBytes = ImageToByteArray(image);

                CloudBlobContainer cloudBlobContainer = await GetCloudBlobContainer(BlobStorageConnection.GetUnApprovedImagesRootContainerReference());

                /*For Nested Directory*/
                //CloudBlockBlob cloudBlockBlob = cloudBlobContainer.GetBlockBlobReference(
                //                                    BlobStorageConnection.GetUnApprovedImagesRootContainerReference() + "/" + imageName);

                CloudBlockBlob cloudBlockBlob = cloudBlobContainer.GetBlockBlobReference(imageName);
                cloudBlockBlob.Properties.ContentType = fileExtensionApplication.Replace(".", string.Empty);
                await cloudBlockBlob.UploadFromByteArrayAsync(imageBytes, 0, imageBytes.Length);

                imageFullPath = cloudBlockBlob.Uri.ToString();

                ReturnUrl returnUrl = new ReturnUrl();
                //returnUrl.OriginialURL = cloudBlockBlob.Uri.ToString();
                returnUrl.OriginialURL = cloudBlockBlob.Uri.AbsolutePath.Substring(1, cloudBlockBlob.Uri.AbsolutePath.Length - 1).ToString();
                returnUrl.WhenUpdateProfileURL = cloudBlockBlob.StorageUri.PrimaryUri.AbsoluteUri.ToString();
                objReturnUrl.Add(returnUrl);
            }
            catch (Exception ex)
            {
            }

            return objReturnUrl;
        }

        public async Task<string> UploadFile(HttpPostedFileBase imageToUpload)
        {
            string imageFullPath = null;
            if (imageToUpload == null || imageToUpload.ContentLength == 0)
            {
                return null;
            }
            try
            {
                //string imageName = Guid.NewGuid().ToString() + Path.GetExtension(imageToUpload.FileName);
                string imageName = Guid.NewGuid().ToString() + fileExtensionApplication;

                CloudBlobContainer cloudBlobContainer = await GetCloudBlobContainer(BlobStorageConnection.GetUnApprovedImagesRootContainerReference());
                CloudBlockBlob cloudBlockBlob = cloudBlobContainer.GetBlockBlobReference(imageName);
                cloudBlockBlob.Properties.ContentType = fileExtensionApplication.Replace(".", string.Empty);
                //cloudBlockBlob.Properties.ContentType = imageToUpload.ContentType;
                await cloudBlockBlob.UploadFromStreamAsync(imageToUpload.InputStream);

                //imageFullPath = cloudBlockBlob.Uri.ToString();
                imageFullPath = cloudBlockBlob.Uri.AbsolutePath.Substring(1, cloudBlockBlob.Uri.AbsolutePath.Length - 1).ToString();
            }
            catch (Exception ex)
            {
            }
            return imageFullPath;
        }

        public async Task<List<ImageDetail>> MoveBlobInSameStorageAccount(List<ImageDetail> imageDetails)
        {
            try
            {
                CloudBlobContainer sourceCloudBlobContainer = await GetCloudBlobContainer(BlobStorageConnection.GetUnApprovedImagesRootContainerReference());
                CloudBlobContainer targetCloudBlobContainer = await GetCloudBlobContainer(BlobStorageConnection.GetImgRootContainerReference());

                foreach (var imageDetail in imageDetails)
                {
                    try
                    {
                        CloudBlockBlob sourceCloudBlockBlob = sourceCloudBlobContainer.GetBlockBlobReference(imageDetail.SourceFilePath);
                        CloudBlockBlob targetCloudBlockBlob = targetCloudBlobContainer.GetBlockBlobReference(imageDetail.TargetFilePath);

                        //if (imageDetail.ImageType == 0 || imageDetail.ImageType == 1)
                        //{
                        //    targetCloudBlockBlob = targetCloudBlobContainer.GetBlockBlobReference(
                        //                                        imageDetail.CategoryName + "/" +
                        //                                        imageDetail.ProfessionalName + "/" +
                        //                                        imageDetail.TargetFilePath);
                        //}
                        //else if (imageDetail.ImageType == 2)
                        //{
                        //    targetCloudBlockBlob = targetCloudBlobContainer.GetBlockBlobReference(
                        //                                        imageDetail.CategoryName + "/" +
                        //                                        imageDetail.ProfessionalName + "/" +
                        //                                        imageDetail.TargetGalleryDir + "/" +
                        //                                        imageDetail.TargetFilePath);
                        //}
                        await targetCloudBlockBlob.StartCopyAsync(sourceCloudBlockBlob);
                        sourceCloudBlockBlob.Delete(DeleteSnapshotsOption.IncludeSnapshots);
                        imageDetail.IsSuccess = true;
                        imageDetail.Message = "Moved";
                    }
                    catch (Exception ex)
                    {
                        imageDetail.IsSuccess = false;
                        imageDetail.Message = "Not Moved";
                    }
                }
            }
            catch (Exception ex)
            { }
            return imageDetails;
        }

        private async Task<CloudBlobContainer> GetCloudBlobContainer(string containerName)
        {
            CloudStorageAccount cloudStorageAccount = BlobStorageConnection.GetConnectionString();
            CloudBlobClient cloudBlobClient = cloudStorageAccount.CreateCloudBlobClient();
            CloudBlobContainer cloudBlobContainer = cloudBlobClient.GetContainerReference(containerName);

            if (await cloudBlobContainer.CreateIfNotExistsAsync())
            {
                await cloudBlobContainer.SetPermissionsAsync(
                    new BlobContainerPermissions
                    {
                        PublicAccess = BlobContainerPublicAccessType.Blob
                    }
                    );
            }
            return cloudBlobContainer;
        }

        private byte[] ImageToByteArray(Image image)
        {
            ImageConverter _imageConverter = new ImageConverter();
            byte[] xByte = (byte[])_imageConverter.ConvertTo(image, typeof(byte[]));
            return xByte;
        }

        private Image Base64ToImage(string base64String)
        {
            byte[] imageBytes = Convert.FromBase64String(base64String);
            using (MemoryStream ms = new MemoryStream(imageBytes, 0, imageBytes.Length))
            {
                ms.Write(imageBytes, 0, imageBytes.Length);
                Image image = Image.FromStream(ms, true);
                return image;
            }
        }

        //private static Image ResizeImage(Image imgToResize, Size size)
        //{
        //    int destWidth = size.Width;
        //    int destHeight = size.Height;

        //    using (Bitmap b = new Bitmap(destWidth, destHeight))
        //    {
        //        Graphics g = Graphics.FromImage((Image)b);
        //        g.InterpolationMode = InterpolationMode.HighQualityBicubic;

        //        g.DrawImage(imgToResize, 0, 0, destWidth, destHeight);
        //        g.Dispose();

        //        return (Image)b;
        //    }
        //}

        //public static Image ResizeImage(Image image, Size size)
        //{
        //    int maxWidth = size.Width;
        //    int maxHeight = size.Height;

        //    var ratioX = (double)maxWidth / image.Width;
        //    var ratioY = (double)maxHeight / image.Height;
        //    var ratio = Math.Min(ratioX, ratioY);

        //    var newWidth = (int)(image.Width * ratio);
        //    var newHeight = (int)(image.Height * ratio);

        //    var newImage = new Bitmap(newWidth, newHeight);

        //    using (var graphics = Graphics.FromImage(newImage))
        //    {
        //        graphics.DrawImage(image, 0, 0, newWidth, newHeight);
        //    }

        //    return newImage;
        //}

        public static Image ResizeImage(Image image, Size size)
        {
            int maxWidth = size.Width;
            int maxHeight = size.Height;

            //var ratioX = (double)maxWidth / image.Width;
            //var ratioY = (double)maxHeight / image.Height;
            //var ratio = Math.Min(ratioX, ratioY);

            //var newWidth = (int)(image.Width * ratio);
            //var newHeight = (int)(image.Height * ratio);

            var newWidth = (int)(maxWidth);
            var newHeight = (int)(maxHeight);

            var newImage = new Bitmap(newWidth, newHeight);

            using (var graphics = Graphics.FromImage(newImage))
                graphics.DrawImage(image, 0, 0, newWidth, newHeight);

            return newImage;
        }
    }
}