﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using EC.WebApps.Helpers;
using EC.Models.Types;

namespace EC.WebApps.Filters
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
    public class AuthorizeJsonAttribute : AuthorizeAttribute
    {
        public override void OnAuthorization(AuthorizationContext filterContext)
        {
            //Create permission string based on the requested controller name and action name in the format 'controllername-action'
            string requiredPermission = String.Format("{0}-{1}",
                                        filterContext.ActionDescriptor.ControllerDescriptor.ControllerName,
                                        filterContext.ActionDescriptor.ActionName);

            //User currentUser = (User)filterContext.RequestContext.HttpContext.Session["UserSession"];
            //Member currentUser = (Member)filterContext.RequestContext.HttpContext.Session["UserSession"];
            
            ////Check if the requesting user has the permission to run the controller's action if (!requestingUser(requiredPermission) & !requestingUser.IsSysAdmin)
            //if (currentUser.Roles.Where(r => r.Permissions != null && r.Permissions.Count > 0).Count() == 0 &&
            //    currentUser.Roles.Where(r => r.IsSysAdmin == false).Count() == 0)
            //{
            //    //User doesn't have the required permission and is not a SysAdmin, return our custom “401 Unauthorized” access error
            //    //Since we are setting filterContext.Result to contain an ActionResult page, the controller's action will not be run.
            //    //The custom “401 Unauthorized” access error will be returned to the browser in response to the initial request.
            //    filterContext.Result = new RedirectToRouteResult(
            //                           new RouteValueDictionary { 
            //                               { "action", "Index" }, 
            //                               { "controller", "AccessDenied" } 
            //                           });
            //}
            ////If the user has the permission to run the controller's action, then filterContext.Result will be uninitialized and
            ////executing the controller's action is dependant on whether filterContext.Result is uninitialized.
        }

        protected override void HandleUnauthorizedRequest(AuthorizationContext filterContext)
        {
            if (filterContext.HttpContext.Request.ContentType.ToLower().Contains("application/json"))
            {
                if (filterContext.HttpContext.Session == null || filterContext.HttpContext.Session["UserSession"] == null)
                {
                    filterContext.Result = new JsonResult
                    {
                        Data = new
                        {
                            // put whatever data you want which will be sent to the client
                            //message = "sorry, but you were logged out"
                            ActiveSession = false,
                            //RedirectTo = "../Account/Login"
                            RedirectTo = "../Account/LogOff"
                        },
                        JsonRequestBehavior = JsonRequestBehavior.AllowGet
                    };

                    //filterContext.Result = new RedirectToRouteResult(new RouteValueDictionary(new { controller = "Account", action = "Login" }));
                }
            }
            else
            {
                base.HandleUnauthorizedRequest(filterContext);
            }
        }
    }
}