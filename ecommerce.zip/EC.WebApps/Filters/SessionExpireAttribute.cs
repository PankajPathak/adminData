﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace EC.WebApps.Filters
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, Inherited = true, AllowMultiple = true)]
    public class SessionExpireAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            HttpContext ctx = HttpContext.Current;

            if (ctx.Session["UserSession"] == null)
            {
                ctx.Response.Redirect("~/Account/Login");
            }

            //// check if session is supported
            //if (ctx.Session != null)
            //{
            //    // check if a new session id was generated
            //    if (ctx.Session.IsNewSession)
            //    {
            //        // If it says it is a new session, but an existing cookie exists, then it must have timed out
            //        string sessionCookie = ctx.Request.Headers["Cookie"];
            //        if ((null != sessionCookie) && (sessionCookie.IndexOf("ASP.NET_SessionId") >= 0))
            //        {
            //            ctx.Response.Redirect("~/Account/Login");
            //        }
            //    }
            //}

            base.OnActionExecuting(filterContext);
        }

        //public override void OnActionExecuting(ActionExecutingContext filterContext)
        //{
        //    HttpSessionStateBase session = filterContext.HttpContext.Session;
        //    // If the browser session or authentication session has expired...
        //    if (session.IsNewSession || HttpContext.Current.Session["UserSession"] == null)
        //    {
        //        if (filterContext.HttpContext.Request.IsAjaxRequest())
        //        {
        //            // For AJAX requests, return result as a simple string, 
        //            // and inform calling JavaScript code that a user should be redirected.
        //            JsonResult result = Json("SessionTimeout", "text/html");
        //            filterContext.Result = result;
        //        }
        //        else
        //        {
        //            // For round-trip requests,
        //            filterContext.Result = new RedirectToRouteResult(
        //                                                                new RouteValueDictionary 
        //                                                                {
        //                                                                    { "Controller", "Account" },
        //                                                                    { "Action", "Login" }
        //                                                                }
        //                                                            );
        //        }
        //    }
        //    base.OnActionExecuting(filterContext);
        //}

        //public override void OnActionExecuting(ActionExecutingContext filterContext)
        //{
        //    HttpContext ctx = HttpContext.Current;
        //    HttpSessionStateBase session = filterContext.HttpContext.Session;

        //    // If the browser session or authentication session has expired...
        //    if (session.IsNewSession || ctx.Session["LoginUser"] == null)
        //    {
        //        if (filterContext.HttpContext.Request.IsAjaxRequest())
        //        {
        //            // For AJAX requests, return result as a simple string, 
        //            // and inform calling JavaScript code that a user should be redirected.
        //            JsonResult result = Json("SessionTimeout", "text/html");

        //            filterContext.Result = result;
        //        }
        //        else
        //        {
        //            // For round-trip requests,
        //            filterContext.Result = new RedirectToRouteResult(new RouteValueDictionary { { "Controller", "Accounts" }, { "Action", "Login" } });
        //        }
        //    }
        //    base.OnActionExecuting(filterContext);
        //}
    }
}