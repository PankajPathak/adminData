﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(EC.WebApps.Startup))]
namespace EC.WebApps
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
